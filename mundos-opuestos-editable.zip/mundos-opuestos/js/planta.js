// Mapa de imágenes, planta 2D/3D con rótulos, fichas de cada lugar, índice y ciclo semanal.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader as GLTFLoaderM } from 'three/addons/loaders/GLTFLoader.js';

const SPACES = window.SPACES, IMG = window.IMG, PHOTOS = window.PHOTOS, CICLO = window.CICLO;
const COL = { pasado:'#E0A064', futuro:'#7FB2E6', presente:'#9CD68F' };
const LAB = { pasado:'mundo pasado', futuro:'mundo futuro', presente:'presente' };
const ORDER = ['presente','futuro','pasado'];
const ZCOL = '#F2D16B';
const ZONES = [
  { id:'z-competencia', nombre:'Zona de competencia', code:'Z1' },
  { id:'z-duelo', nombre:'Zona de duelo', code:'Z2' }
].map(z => ({ ...z, zona:true, mundo:'zona', paleta:[], texturas:[], mobiliario:[] }));
const TOUR_OF = { patio:'acceso', porton:'acceso', espejo:'espejo', 'puente-futuro':'espejo', 'puente-pasado':'rollizos', 'portal-futuro':'portal-futuro',
  'bano-futuro':'bano-futuro', 'camas-futuro':'camas-futuro', estar:'estar', living:'living', comedor:'comedor', 'cocina-futuro':'cocina-futuro',
  'jardin-futuro':'comedor', 'camas-pasado':'camas-pasado', arbol:'arbol', explanada:'arbol', rollizos:'rollizos', piscina:'acceso', 'z-cara':'acceso' };
const $ = s => document.querySelector(s);
const host = $('#planStage');
const small = () => innerWidth <= 760;
// numeración estable: presente, futuro, pasado
const ORDERED = ORDER.flatMap(m => SPACES.filter(s => s.mundo === m));
ORDERED.forEach((s, i) => s.code = String(i + 1).padStart(2, '0'));

// ---------- escena ----------
const renderer = new THREE.WebGLRenderer({ antialias:true, alpha:true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.setClearColor(0x000000, 0);
host.appendChild(renderer.domElement);
const scene = new THREE.Scene();
scene.add(new THREE.HemisphereLight(0xffffff, 0x6c7688, 1.5));
const dl = new THREE.DirectionalLight(0xffffff, 1.2); dl.position.set(-40, 80, -30); scene.add(dl);

const CX = 40, CZ = 27;
const cam = new THREE.OrthographicCamera(-1, 1, 1, -1, -500, 1000);
const controls = new OrbitControls(cam, renderer.domElement);
controls.target.set(CX, 0, CZ);
const TOP = new THREE.Vector3(0, 160, -0.01), TILT = new THREE.Vector3(0, 95, -100);
cam.position.copy(controls.target).add(TOP);
controls.enableDamping = true; controls.dampingFactor = 0.08;
controls.enableRotate = false; controls.screenSpacePanning = true;
controls.minZoom = 0.6; controls.maxZoom = 6;
controls.minAzimuthAngle = Math.PI - 0.7; controls.maxAzimuthAngle = -Math.PI + 0.7;
controls.maxPolarAngle = 1.02;
controls.mouseButtons = { LEFT: THREE.MOUSE.PAN, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.ROTATE };
controls.touches = { ONE: THREE.TOUCH.PAN, TWO: THREE.TOUCH.DOLLY_PAN };

let panelOpen = false;
function fit(){
  const w = innerWidth, h = innerHeight; renderer.setSize(w, h, false);
  const span = small() ? 90 : 104, aspect = w / h, half = span / 2;
  if (aspect >= 1){ cam.left = -half*aspect; cam.right = half*aspect; cam.top = half; cam.bottom = -half; }
  else { cam.left = -half; cam.right = half; cam.top = half/aspect; cam.bottom = -half/aspect; }
  const pw = (panelOpen && !small()) ? $('#lugar').offsetWidth + 16 : 0;
  cam.setViewOffset(w, h, pw/2, small() ? 30 : 0, w, h);
  cam.updateProjectionMatrix(); relayout();
}
addEventListener('resize', fit);

// ---------- planta ----------
(async () => {
  const bmp = await window.loadBitmap(IMG.plan);
  const tex = new THREE.Texture(bmp); tex.needsUpdate = true; tex.flipY = false; tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  const X0 = -12, X1 = 78, Z0 = -30, Z1 = 80, g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute([X1,0,Z1, X0,0,Z1, X1,0,Z0, X0,0,Z0], 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute([0,0, 1,0, 0,1, 1,1], 2));
  g.setIndex([0,2,1, 1,2,3]);
  scene.add(new THREE.Mesh(g, new THREE.MeshBasicMaterial({ map:tex, transparent:true, side:THREE.DoubleSide, depthWrite:false })));
})();
const grid = new THREE.GridHelper(160, 32, 0x3a5a86, 0x1d2c44); grid.position.set(CX, -0.05, CZ);
grid.material.transparent = true; grid.material.opacity = 0.45; scene.add(grid);

// ---------- espacios ----------
const groups = [], pickables = [];
for (const sp of ORDERED){
  const shape = new THREE.Shape(); let cx = 0, cz = 0;
  if (sp.circle){ const [x, z, r] = sp.circle; shape.absarc(x, -z, r, 0, Math.PI*2, false); cx = x; cz = z; }
  else { sp.poly.forEach(([x, z], i) => { i ? shape.lineTo(x, -z) : shape.moveTo(x, -z); cx += x; cz += z; }); cx /= sp.poly.length; cz /= sp.poly.length; }
  if (sp.id === 'patio'){ cx = 38; cz = 2; }
  const depth = sp.id === 'patio' ? 0.5 : 1.4 + sp.h * 1.6;
  const geo = new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled:false, curveSegments:40 });
  geo.rotateX(-Math.PI/2);
  const col = new THREE.Color(COL[sp.mundo]);
  const mat = new THREE.MeshStandardMaterial({ color:col, transparent:true, opacity:0.2, depthWrite:false, roughness:.6, emissive:col, emissiveIntensity:0.15, side:THREE.DoubleSide });
  const mesh = new THREE.Mesh(geo, mat); mesh.renderOrder = 2;
  const edges = new THREE.LineSegments(new THREE.EdgesGeometry(geo, 20), new THREE.LineBasicMaterial({ color:col, transparent:true, opacity:0.85 }));
  edges.renderOrder = 3;
  const grp = new THREE.Group(); grp.add(mesh, edges); grp.position.y = 0.06;
  grp.userData = { sp, mesh, edges, lift:0, target:0, anchor: new THREE.Vector3(cx, depth, cz), off:[0,-80] };
  mesh.userData.grp = grp;
  scene.add(grp); groups.push(grp); pickables.push(mesh);
}
const byId = id => groups.find(g => g.userData.sp.id === id);

// ---------- rótulos tipo HUD ----------
const hud = $('#hud'), svg = $('#hudLines');
for (const g of groups){
  const sp = g.userData.sp, el = document.createElement('button');
  el.className = 'callout'; el.style.setProperty('--c', COL[sp.mundo]);
  const nf = (PHOTOS[sp.id] || []).length;
  el.innerHTML = `<b>MO# ${sp.code}</b><strong>${sp.nombre}</strong><em>${LAB[sp.mundo]}</em>
    <span class="data"><span class="pic"></span><span class="sw">${sp.paleta.map(h => `<i style="background:${h}"></i>`).join('')}</span>
    <span class="nums"><span>fotos <u>${nf}</u></span><span>materiales <u>${sp.texturas.length}</u></span><span>colores <u>${sp.paleta.length}</u></span></span></span>`;
  el.onclick = () => openLugar(sp.id);
  el.onmouseenter = () => { if (g !== selected) g.userData.target = 1; el.classList.add('hot'); loadPic(g); };
  el.onmouseleave = () => { if (g !== selected) g.userData.target = 0; el.classList.remove('hot'); };
  hud.appendChild(el); g.userData.el = el;
  const line = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
  const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle'); dot.setAttribute('r', 3.2);
  line.style.stroke = dot.style.fill = COL[sp.mundo];
  svg.append(line, dot); g.userData.line = line; g.userData.dot = dot;
}
// imagen del lugar al hacer hover (se carga la primera vez)
function loadPic(g){
  const u = g.userData, k = (PHOTOS[u.sp.id] || [])[0], box = u.el.querySelector('.pic');
  if (!k || box.firstChild) return;
  const im = new Image(); im.alt = ''; im.src = IMG[k]; box.appendChild(im);
}
const v = new THREE.Vector3();
function anchorPx(g){
  const u = g.userData; v.copy(u.anchor); v.y = (u.anchor.y) * g.scale.y + g.position.y; v.project(cam);
  return [(v.x*.5 + .5) * innerWidth, (-v.y*.5 + .5) * innerHeight];
}
// coloca los rótulos sin que se tapen entre sí (se recalcula cuando la cámara se detiene)
function relayout(){
  const W = innerWidth, H = innerHeight, placed = [];
  const safeR = W - ((panelOpen && !small()) ? $('#lugar').offsetWidth + 24 : 12), safeT = small() ? 150 : 128, safeB = H - (small() ? 130 : 20), safeLx = small() ? 8 : 12;
  const vis = groups.filter(g => g.visible);
  const P = new Map(vis.map(g => [g, anchorPx(g)]));
  // núcleo del set (todo menos el Presente): los rótulos se ubican alrededor, como en un plano con fichas
  const core = vis.filter(g => g.userData.sp.mundo !== 'presente').map(g => P.get(g));
  const obst = core.length ? { x: Math.min(...core.map(p => p[0])) - 18, y: Math.min(...core.map(p => p[1])) - 18,
    x2: Math.max(...core.map(p => p[0])) + 18, y2: Math.max(...core.map(p => p[1])) + 18 } : null;
  const C = core.length ? [(obst.x + obst.x2)/2, (obst.y + obst.y2)/2] : [W/2, H/2];
  // reservar la leyenda (abajo a la izquierda)
  const leg = $('#legend').getBoundingClientRect(); placed.push({ x: leg.left, y: leg.top, w: leg.width + 10, h: leg.height });
  const order = vis.slice().sort((a, b) => Math.atan2(P.get(a)[1] - C[1], P.get(a)[0] - C[0]) - Math.atan2(P.get(b)[1] - C[1], P.get(b)[0] - C[0]));
  for (const g of order){
    const [ax, ay] = P.get(g), el = g.userData.el, bw = el.offsetWidth || 170, bh = el.offsetHeight || 48;
    const inCore = g.userData.sp.mundo !== 'presente';
    let base = Math.atan2(ay - C[1], ax - C[0]); if (Math.hypot(ax - C[0], ay - C[1]) < 8) base = -Math.PI/2;
    let best = null;
    outer: for (const d of inCore ? [60, 100, 140, 180, 230, 290, 360, 440] : [50, 90, 140, 200]){
      for (const dev of [0, 18, -18, 36, -36, 54, -54, 72, -72, 100, -100, 140, -140, 180]){
        const ang = base + dev * Math.PI / 180;
        const dx = Math.cos(ang) * d, dy = Math.sin(ang) * d;
        const x = ax + dx - (dx < -bw*0.15 ? bw : dx > bw*0.15 ? 0 : bw/2), y = ay + dy - (dy < -4 ? bh : dy > 4 ? 0 : bh/2);
        const r = { x, y, w: bw, h: bh };
        if (r.x < safeLx || r.x + r.w > safeR || r.y < safeT || r.y + r.h > safeB) continue;
        if (inCore && obst && r.x < obst.x2 && r.x + r.w > obst.x && r.y < obst.y2 && r.y + r.h > obst.y) continue;
        if (placed.some(p => r.x < p.x + p.w + 8 && r.x + r.w + 8 > p.x && r.y < p.y + p.h + 8 && r.y + r.h + 8 > p.y)) continue;
        best = r; break outer;
      }
    }
    if (!best) best = { x: Math.min(Math.max(safeLx, ax - bw/2), safeR - bw), y: Math.min(Math.max(safeT, ay - 60 - bh), safeB - bh), w: bw, h: bh };
    placed.push(best); g.userData.off = [best.x - ax, best.y - ay];
  }
}
let moving = false, stillT = 0;
controls.addEventListener('change', () => { moving = true; stillT = performance.now(); });
function drawHud(){
  for (const g of groups){
    const u = g.userData, el = u.el;
    if (!g.visible){ el.style.display = 'none'; u.line.style.display = u.dot.style.display = 'none'; continue; }
    el.style.display = ''; u.line.style.display = u.dot.style.display = '';
    const [ax, ay] = anchorPx(g), x = ax + u.off[0], y = ay + u.off[1], w = el.offsetWidth, h = el.offsetHeight;
    el.style.transform = `translate(${x}px, ${y}px)`;
    // la línea sale del borde del rótulo más cercano al punto y baja en vertical, como en la referencia
    // línea desde la esquina del rótulo más cercana: primero vertical y luego al punto, como en la referencia
    const ex = ax < x ? x : (ax > x + w ? x + w : ax), ey = ay < y ? y : (ay > y + h ? y + h : y + h);
    const inside = ax >= x && ax <= x + w;
    u.line.setAttribute('points', inside ? `${ax},${ey} ${ax},${ay}` : `${ex},${ey} ${ex},${ay} ${ax},${ay}`);
    u.dot.setAttribute('cx', ax); u.dot.setAttribute('cy', ay);
    el.classList.toggle('sel', g === selected);
  }
}

// ---------- 2D / 3D ----------
let dim = 0, dimT = 0, camAnim = null;
function set3D(on){
  dimT = on ? 1 : 0; controls.enableRotate = on;
  $('#v2d').setAttribute('aria-pressed', !on); $('#v3d').setAttribute('aria-pressed', on);
  camAnim = { t0: performance.now(), from: cam.position.clone().sub(controls.target), to: (on ? TILT : TOP).clone() };
}
$('#v2d').onclick = () => set3D(false);
$('#v3d').onclick = () => set3D(true);

// ---------- hover / clic en la planta ----------
const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
let hover = null, selected = null, downAt = null;
const hidden = new Set();
const area = o => { const b = o.geometry.boundingBox || (o.geometry.computeBoundingBox(), o.geometry.boundingBox); return (b.max.x-b.min.x)*(b.max.z-b.min.z); };
function pick(ev){
  const r = renderer.domElement.getBoundingClientRect();
  ndc.set(((ev.clientX - r.left)/r.width)*2 - 1, -((ev.clientY - r.top)/r.height)*2 + 1);
  ray.setFromCamera(ndc, cam);
  const hits = ray.intersectObjects(pickables.filter(m => m.userData.grp.visible), false);
  if (!hits.length) return null;
  hits.sort((a, b) => area(a.object) - area(b.object));
  return hits[0].object.userData.grp;
}
function setHover(g){
  if (hover && hover !== g){ if (hover !== selected) hover.userData.target = 0; hover.userData.el.classList.remove('hot'); }
  hover = g;
  if (g){ if (g !== selected) g.userData.target = 1; g.userData.el.classList.add('hot'); loadPic(g); renderer.domElement.style.cursor = 'pointer'; }
  else renderer.domElement.style.cursor = '';
}
renderer.domElement.addEventListener('pointermove', ev => { if (ev.pointerType !== 'touch') setHover(pick(ev)); });
renderer.domElement.addEventListener('pointerleave', () => setHover(null));
renderer.domElement.addEventListener('pointerdown', ev => { downAt = [ev.clientX, ev.clientY]; });
renderer.domElement.addEventListener('pointerup', ev => {
  if (!downAt || Math.hypot(ev.clientX - downAt[0], ev.clientY - downAt[1]) > 6) return;
  const g = pick(ev); if (g) openLugar(g.userData.sp.id);
});

// ---------- índice de lugares (plegable) ----------
const lista = $('#lista ol'), prev = $('#preview');
function showPreview(li, sp){
  const k = (PHOTOS[sp.id] || [])[0], r = li.getBoundingClientRect(), lr = $('#lista').getBoundingClientRect();
  prev.style.setProperty('--c', sp.zona ? ZCOL : COL[sp.mundo]);
  prev.innerHTML = (k ? `<img src="${IMG[k]}" alt="">` : '<div class="nofoto">Sin fotos todavía</div>') + `<span><b>${sp.zona ? sp.code : 'MO# ' + sp.code}</b>${sp.nombre}</span>`;
  if (small()) return;
  prev.style.transform = `translate(${lr.left - 272}px, ${Math.max(90, Math.min(innerHeight - 200, r.top - 50))}px)`;
  prev.classList.add('on');
}
const hidePreview = () => prev.classList.remove('on');
{
  const head = document.createElement('li'); head.className = 'grp'; head.style.setProperty('--c', ZCOL); head.textContent = 'zonas de juego'; lista.appendChild(head);
  const li = document.createElement('li'); li.className = 'zonas';
  li.innerHTML = ZONES.map(z => `<button data-z="${z.id}"><i>${z.code}</i><span>${z.nombre}</span></button>`).join('');
  lista.appendChild(li);
  li.querySelectorAll('button').forEach(b => { const z = ZONES.find(x => x.id === b.dataset.z);
    b.onclick = () => { hidePreview(); openLugar(z.id); $('#lista').classList.remove('open'); $('#bLista').setAttribute('aria-expanded', false); };
    b.onmouseenter = () => showPreview(b, z); b.onmouseleave = hidePreview; });
}
ORDER.forEach(m => {
  const head = document.createElement('li'); head.className = 'grp'; head.style.setProperty('--c', COL[m]); head.textContent = LAB[m]; lista.appendChild(head);
  ORDERED.filter(s => s.mundo === m).forEach(sp => {
    const li = document.createElement('li'); li.dataset.id = sp.id; li.style.setProperty('--c', COL[sp.mundo]);
    li.innerHTML = `<button><i>${sp.code}</i><span>${sp.nombre}</span></button>`;
    li.querySelector('button').onclick = () => { hidePreview(); openLugar(sp.id); $('#lista').classList.remove('open'); $('#bLista').setAttribute('aria-expanded', false); };
    li.onmouseenter = () => { showPreview(li, sp); const g = byId(sp.id); if (g && g !== selected) g.userData.target = 1; };
    li.onmouseleave = () => { hidePreview(); const g = byId(sp.id); if (g && g !== selected) g.userData.target = 0; };
    lista.appendChild(li);
  });
});
$('#bLista').onclick = () => { const o = $('#lista').classList.toggle('open'); $('#bLista').setAttribute('aria-expanded', o); if (!o) hidePreview(); };

// ---------- ficha: fotos primero, luego menús plegables ----------
const lugar = $('#lugar');
let photoIx = 0;
let current = null;
function openLugar(id){
  const z = ZONES.find(x => x.id === id);
  if (z){
    if (selected){ selected.userData.target = 0; selected = null; }
    current = z; photoIx = 0; renderLugar();
    lugar.classList.remove('open'); void lugar.offsetWidth; lugar.classList.add('open');
    panelOpen = true; fit(); return;
  }
  const g = byId(id); if (!g) return;
  if (selected && selected !== g) selected.userData.target = 0;
  selected = g; current = g.userData.sp; g.userData.target = 1.8; photoIx = 0;
  renderLugar();
  lugar.classList.remove('open'); void lugar.offsetWidth; lugar.classList.add('open');
  panelOpen = true; fit();
  if (document.body.dataset.mode === 'plan') panTo(g.userData.anchor);
}
function closeLugar(){
  lugar.classList.remove('open'); panelOpen = false; current = null; fit();
  if (selected){ selected.userData.target = 0; selected = null; }
}
function renderLugar(){
  const sp = current, fotos = (PHOTOS[sp.id] || []).map(k => IMG[k]);
  lugar.style.setProperty('--c', sp.zona ? ZCOL : COL[sp.mundo]);
  const hero = fotos.length
    ? `<div class="hero"><img src="${fotos[0]}" alt="${sp.nombre}, imagen 1">
        ${fotos.length > 1 ? `<button class="nav prev" aria-label="Foto anterior">‹</button><button class="nav next" aria-label="Foto siguiente">›</button>
        <div class="dots">${fotos.map((_, i) => `<button aria-label="Foto ${i + 1}" aria-current="${i === 0}"></button>`).join('')}</div>
        <span class="count">1 / ${fotos.length}</span>` : ''}</div>
       ${fotos.length > 1 ? `<div class="thumbs">${fotos.map((u, i) => `<button aria-label="Ver foto ${i+1}" aria-current="${i === 0}"><img src="${u}" alt=""></button>`).join('')}</div>` : ''}`
    : `<div class="hero empty"><p>Sin fotos de este sector todavía</p></div>`;
  const ring = (items, kind) => `<div class="ring" style="--n:${items.length}">${items.map((it, i) =>
      `<button class="dotc ${kind}" style="--i:${i};--a:${items.length > 1 ? -80 + i * (160 / (items.length - 1)) : 0}deg;${kind === 'color' ? `background:${it}` : `background-image:url(${it.img})`}" title="${kind === 'color' ? it : it.nombre}"></button>`).join('')}</div>`;
  const colores = sp.paleta.length ? `${ring(sp.paleta, 'color')}<ul class="leg">${sp.paleta.map(h => `<li><i style="background:${h}"></i><code>${h}</code></li>`).join('')}</ul>`
    : '<p class="empty">Sin colores registrados en el modelo.</p>';
  const texturas = sp.texturas.length ? `${ring(sp.texturas, 'mat')}<ul class="leg">${sp.texturas.map(t => `<li><i style="background-image:url(${t.img})"></i>${t.nombre}</li>`).join('')}</ul>`
    : '<p class="empty">Acabados de color liso, sin texturas en el modelo.</p>';
  const mob = mobImgs(sp.id) + (sp.mobiliario.length ? `<ul class="mob">${sp.mobiliario.map(x => `<li>${x}</li>`).join('')}</ul>` : '<p class="empty">Sin mobiliario registrado en el modelo.</p>');
  if (sp.zona){
    lugar.innerHTML = `
    <header class="lh"><div><b>${sp.code}</b><em>zona de juego</em><h2>${sp.nombre}</h2></div><button class="x" aria-label="Cerrar">×</button></header>
    ${hero}
    <p class="znote">Ubicación en la planta por definir.</p>`;
  } else lugar.innerHTML = `
    <header class="lh"><div><b>MO# ${sp.code}</b><em>${LAB[sp.mundo]}</em><h2>${sp.nombre}</h2></div><button class="x" aria-label="Cerrar">×</button></header>
    ${hero}
    <div class="acc">
      <details data-k="colores"><summary><span>Colores</span><small>${sp.paleta.length}</small></summary><div class="in">${colores}</div></details>
      <details data-k="texturas"><summary><span>Texturas</span><small>${sp.texturas.length}</small></summary><div class="in">${texturas}</div></details>
      <details data-k="mobiliario"><summary><span>Mobiliario</span><small>${sp.mobiliario.length}</small></summary><div class="in">${mob}</div></details>
    </div>
    <div class="acts">${BR[sp.id] ? `<button class="btn brandb">Ver branding · ${BR[sp.id].map(b => b.marca).join(' / ')}</button>` : ''}<button class="btn tour">Ver este sector en el recorrido 3D</button></div>`;
  lugar.querySelector('.brandb')?.addEventListener('click', () => openBrand(sp.id));
  lugar.querySelector('.x').onclick = closeLugar;
  lugar.querySelector('.tour')?.addEventListener('click', () => { closeLugar(); window.openTour(TOUR_OF[sp.id] || 'acceso'); });
  const go = i => { photoIx = (i + fotos.length) % fotos.length; const img = lugar.querySelector('.hero img'); img.style.opacity = 0;
    setTimeout(() => { img.src = fotos[photoIx]; img.style.opacity = 1; }, 150);
    lugar.querySelectorAll('.dots button, .thumbs button').forEach(b => b.setAttribute('aria-current', false));
    lugar.querySelectorAll('.dots button')[photoIx]?.setAttribute('aria-current', true); lugar.querySelectorAll('.thumbs button')[photoIx]?.setAttribute('aria-current', true);
    const c = lugar.querySelector('.count'); if (c) c.textContent = `${photoIx + 1} / ${fotos.length}`; };
  lugar.querySelector('.prev')?.addEventListener('click', () => go(photoIx - 1));
  lugar.querySelector('.next')?.addEventListener('click', () => go(photoIx + 1));
  lugar.querySelectorAll('.dots button').forEach((b, i) => b.onclick = () => go(i));
  lugar.querySelectorAll('.thumbs button').forEach((b, i) => b.onclick = () => go(i));
  const hi = lugar.querySelector('.hero img'); if (hi) hi.onclick = () => window.showLightbox(hi.src);
  lugar.querySelectorAll('.dotc.color').forEach(b => b.onclick = async () => { try { await navigator.clipboard.writeText(b.title); b.classList.add('ok'); setTimeout(() => b.classList.remove('ok'), 900); } catch(_){} });
  lugar.querySelectorAll('.dotc.mat').forEach(b => b.onclick = () => { const m = /url\("?(.*?)"?\)/.exec(b.style.backgroundImage); if (m) window.showLightbox(m[1]); });
  // un menú abierto a la vez
  lugar.querySelectorAll('details').forEach(d => d.addEventListener('toggle', () => { if (d.open) lugar.querySelectorAll('details').forEach(o => { if (o !== d) o.open = false; }); }));
  lugar.scrollTop = 0;
}

// ---------- leyenda ----------
document.querySelectorAll('#legend .key').forEach(k => k.onclick = () => {
  const m = k.dataset.m, on = k.getAttribute('aria-pressed') === 'true';
  k.setAttribute('aria-pressed', !on); on ? hidden.add(m) : hidden.delete(m);
  groups.forEach(g => g.visible = !hidden.has(g.userData.sp.mundo));
  if (selected && !selected.visible) closeLugar();
  relayout();
});

// ---------- animación ----------
let pan = null;
function panTo(c){ pan = { t0: performance.now(), a: controls.target.clone(), b: new THREE.Vector3(c.x, 0, c.z) }; }
const ease = t => 1 - Math.pow(1 - t, 3);
let lastDim = 0;
function loop(now){
  if (pan){ const t = Math.min(1, (now - pan.t0)/700), k = ease(t), off = cam.position.clone().sub(controls.target);
    controls.target.lerpVectors(pan.a, pan.b, k); cam.position.copy(controls.target).add(off); moving = true; stillT = now; if (t >= 1) pan = null; }
  if (camAnim){ const t = Math.min(1, (now - camAnim.t0)/900), k = ease(t);
    cam.position.copy(controls.target).add(camAnim.from.clone().lerp(camAnim.to, k)); moving = true; stillT = now; if (t >= 1) camAnim = null; }
  dim += (dimT - dim) * 0.12;
  if (Math.abs(dim - lastDim) > 0.002){ moving = true; stillT = now; lastDim = dim; }
  for (const g of groups){
    const u = g.userData; u.lift += (u.target - u.lift) * 0.18;
    g.scale.y = 0.02 + dim * 0.98; g.position.y = 0.06 + u.lift * 1.8 * dim;
    u.mesh.material.opacity = 0.2 + u.lift * 0.22; u.mesh.material.emissiveIntensity = 0.15 + u.lift * 0.4;
    u.edges.material.opacity = 0.75 + Math.min(u.lift, 1) * 0.25;
  }
  controls.update(); renderer.render(scene, cam);
  if (moving && now - stillT > 180){ moving = false; relayout(); }
  drawHud();
}
fit(); setTimeout(fit, 400); renderer.setAnimationLoop(loop);

// ---------- mapa de imágenes (mosaico ordenado como la planta: norte arriba, Futuro a la izquierda, Pasado a la derecha) ----------
// encuadre de la foto en el mosaico cuando dos lugares comparten imagen (se muestra la parte que corresponde a cada uno)
const FOCUS = { 'jardin-futuro':['15% 70%', 1.6], 'portal-futuro':['30% 45%', 1.5], 'puente-futuro':['60% 88%', 1.7], porton:['48% 42%', 1.5], piscina:['4% 85%', 1.9] };
// Categorías de la portada: cada una se abre con la imagen de su puente o lugar principal
const CATS = [
  { id:'futuro', t:'Mundo Futuro', k:'', cover:'puente-futuro', pos:'32% 50%', col:COL.futuro,
    ids:['puente-futuro','portal-futuro','living','camas-futuro','bano-futuro','comedor','cocina-futuro','estar','jardin-futuro'] },
  { id:'pasado', t:'Mundo Pasado', k:'', cover:'puente-pasado', pos:'55% 50%', col:COL.pasado,
    ids:['puente-pasado','camas-pasado','arbol','explanada','rollizos'] },
  { id:'presente', t:'Patio del Presente', k:'', cover:'patio', pos:'45% 50%', col:COL.presente,
    ids:['patio','porton','espejo','piscina'] },
  { id:'zonas', t:'Zonas de juego', k:'Competencia · duelo · cara a cara', cover:'z-competencia', pos:'50% 50%', col:ZCOL,
    ids: [...ZONES.map(z => z.id), 'z-cara'] }
];
const spOf = id => ZONES.find(z => z.id === id) || SPACES.find(s => s.id === id);
const cats = $('#mosaico .cats'), cview = $('#mosaico .catview'), mgrid = $('#mosaico .grid');
let curCat = null;
for (const c of CATS){
  const cover = (PHOTOS[c.cover] || [])[0], b = document.createElement('button'); b.className = 'cat'; b.style.setProperty('--c', c.col);
  b.style.setProperty('--pos', c.pos);
  b.innerHTML = `${cover ? `<img src="${IMG[cover]}" alt="">` : ''}
    <span class="ct">${c.k ? `<small>${c.k}</small>` : ''}<strong>${c.t}</strong>
    <em>${c.ids.map(id => spOf(id)?.nombre).filter(Boolean).join(' · ')}</em>
    <u>Ver ${c.ids.length} lugares →</u></span>`;
  b.onclick = () => openCat(c.id);
  cats.appendChild(b);
}
const tabs = $('#mosaico .cvtabs');
CATS.forEach(c => { const t = document.createElement('button'); t.textContent = c.t; t.style.setProperty('--c', c.col); t.onclick = () => openCat(c.id); t.dataset.c = c.id; tabs.appendChild(t); });
function tileFor(id){
  const sp = spOf(id); if (!sp) return null;
  const fotos = PHOTOS[id] || [], col = sp.zona ? ZCOL : COL[sp.mundo];
  const t = document.createElement('button'); t.className = 'tile' + (fotos.length ? '' : ' nofoto');
  t.style.setProperty('--c', col);
  if (FOCUS[id]){ t.style.setProperty('--pos', FOCUS[id][0]); t.style.setProperty('--z', FOCUS[id][1]); }
  const que = sp.zona ? 'Zona de juego · ubicación en la planta por definir'
    : `${LAB[sp.mundo].replace(/^./, ch => ch.toUpperCase())}${sp.mobiliario.length ? ' · ' + sp.mobiliario.slice(0, 2).join(' · ') : ''}`;
  t.setAttribute('aria-label', sp.nombre);
  t.innerHTML = `${fotos.length ? `<img src="${IMG[fotos[0]]}" alt="" loading="lazy">` : ''}
    <span class="name0">${sp.nombre}</span>${BR[id] ? '<span class="bbadge">Brandeable</span>' : ''}
    <span class="cap"><strong>${sp.nombre}</strong><em>${que}</em><small>Clic para ver todo →</small></span>`;
  t.onclick = () => openFicha(id);
  let timer = null, ix = 0;
  t.onmouseenter = () => { if (fotos.length < 2) return; timer = setInterval(() => { ix = (ix + 1) % fotos.length; t.querySelector('img').src = IMG[fotos[ix]]; }, 1300); };
  t.onmouseleave = () => { clearInterval(timer); if (fotos.length > 1){ ix = 0; t.querySelector('img').src = IMG[fotos[0]]; } };
  return t;
}
function openCat(id){
  const c = CATS.find(x => x.id === id); curCat = c;
  cview.style.setProperty('--c', c.col);
  cview.querySelector('.cvk').textContent = c.k || (c.ids.length + ' lugares'); cview.querySelector('.cvt').textContent = c.t;
  tabs.querySelectorAll('button').forEach(b => b.setAttribute('aria-current', b.dataset.c === id));
  mgrid.innerHTML = ''; c.ids.forEach(i => { const t = tileFor(i); if (t) mgrid.appendChild(t); });
  mgrid.dataset.n = c.ids.length;
  cats.hidden = true; cview.hidden = false; cview.scrollTop = 0; mgrid.scrollTop = 0;
}
function closeCat(){ curCat = null; cview.hidden = true; cats.hidden = false; }
cview.querySelector('.back').onclick = closeCat;

// ---------- branding de espacios (referencias del PDF "Espacios Branding") ----------
const BR = window.BRANDING || {};
const brandEl = $('#brand');
let bState = null;
function openBrand(id, bi = 0, ii = 0){
  const list = BR[id]; if (!list) return;
  const sp = spOf(id), b = list[bi]; bState = { id, bi, ii };
  brandEl.style.setProperty('--b', b.color);
  brandEl.innerHTML = `<div class="bwrap">
    <header><div><p class="bk">Espacio brandeable · ${sp.nombre}</p><h2>${b.marca}</h2></div>
      ${list.length > 1 ? `<nav class="btabs">${list.map((x, k) => `<button style="--b:${x.color}" aria-current="${k === bi}" data-k="${k}">${x.marca}</button>`).join('')}</nav>` : ''}
      <button class="bclose" aria-label="Cerrar">×</button></header>
    <div class="bbody">
      <figure><img src="${IMG[b.imgs[ii]]}" alt="Referencia de branding ${b.marca} en ${sp.nombre}">
        ${b.imgs.length > 1 ? `<button class="bn bp" aria-label="Anterior">‹</button><button class="bn bx" aria-label="Siguiente">›</button><span class="bc">${ii + 1} / ${b.imgs.length}</span>` : ''}</figure>
      <aside><h3>Cómo se integra la marca</h3><ul>${b.elementos.map(e => `<li>${e}</li>`).join('')}</ul>
        <p class="bsrc">Imágenes de referencia del documento Espacios Branding.</p></aside>
    </div></div>`;
  brandEl.querySelector('.bclose').onclick = closeBrand;
  brandEl.querySelectorAll('.btabs button').forEach(t => t.onclick = () => openBrand(id, +t.dataset.k, 0));
  brandEl.querySelector('.bp')?.addEventListener('click', () => openBrand(id, bi, (ii - 1 + b.imgs.length) % b.imgs.length));
  brandEl.querySelector('.bx')?.addEventListener('click', () => openBrand(id, bi, (ii + 1) % b.imgs.length));
  brandEl.querySelector('figure img').onclick = e => window.showLightbox(e.target.src);
  brandEl.classList.add('open');
}
function closeBrand(){ brandEl.classList.remove('open'); bState = null; }
brandEl.addEventListener('click', e => { if (e.target === brandEl) closeBrand(); });
addEventListener('keydown', e => { if (!bState) return;
  if (e.key === 'Escape' && $('#lightbox').style.display !== 'grid'){ e.stopImmediatePropagation(); closeBrand(); } }, true);

const MOB = window.MOBIMG || {};
const M3 = window.MOB3D || {}, M3DE = window.MOB3D_DE || {};
const mobImgs = id => ((MOB[id] || []).length ? `<div class="mobimg">${MOB[id].map(k => `<button><img src="${IMG[k]}" alt="Mobiliario"></button>`).join('')}</div>` : '')
  + ((M3DE[id] || []).length ? `<div class="mob3dlist">${M3DE[id].map(k => `<div class="m3"><span><b>${M3[k].nombre}</b><small>Modelo 3D y plano para CNC</small></span><button class="btn" data-m3="${k}" data-v="3d">Ver en 3D</button><button class="btn ghost" data-m3="${k}" data-v="cnc">Plano CNC</button></div>`).join('')}</div>` : '');
document.addEventListener('click', e => { const b = e.target.closest('[data-m3]'); if (b) openMob3D(b.dataset.m3, b.dataset.v); });
// ---------- mueble en 3D + plano CNC ----------
async function bytesOf(src){
  if (src.startsWith('data:')){
    const [head, b64] = src.split(','); const bin = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
    if (head.includes('application/gzip')) return new Uint8Array(await new Response(new Blob([bin]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());
    return bin;
  }
  return new Uint8Array(await (await fetch(src)).arrayBuffer());
}
const m3el = document.getElementById('mob3d');
let m3r = null, m3scene, m3cam, m3ctl, m3obj = null, m3raf = null;
function m3init(host){
  m3r = new THREE.WebGLRenderer({ antialias:true, alpha:true }); m3r.setPixelRatio(Math.min(devicePixelRatio, 2));
  m3r.outputColorSpace = THREE.SRGBColorSpace; m3r.toneMapping = THREE.ACESFilmicToneMapping;
  m3scene = new THREE.Scene();
  m3scene.add(new THREE.HemisphereLight(0xffffff, 0x445066, 1.6));
  const d1 = new THREE.DirectionalLight(0xffffff, 2); d1.position.set(3, 5, 4); m3scene.add(d1);
  const d2 = new THREE.DirectionalLight(0x9fc4ff, 0.8); d2.position.set(-4, 2, -3); m3scene.add(d2);
  m3cam = new THREE.PerspectiveCamera(35, 1, 0.01, 100);
  m3ctl = new OrbitControls(m3cam, m3r.domElement); m3ctl.enableDamping = true;
  const g = new THREE.GridHelper(8, 32, 0x3a5a86, 0x1d2c44); g.material.transparent = true; g.material.opacity = .5; m3scene.add(g);
}
async function openMob3D(k, view){
  const p = M3[k]; if (!p) return;
  m3el.innerHTML = `<div class="m3wrap"><header><div><p class="bk">Mobiliario · referencia 3D</p><h2>${p.nombre}</h2></div>
    <nav class="m3tabs"><button data-t="3d" aria-current="${view !== 'cnc'}">Modelo 3D</button><button data-t="cnc" aria-current="${view === 'cnc'}">Plano CNC</button></nav>
    <button class="bclose" aria-label="Cerrar">×</button></header>
    <div class="m3body"><div class="m3view" ${view === 'cnc' ? 'hidden' : ''}><div class="m3canvas"></div><p class="m3dims"></p><p class="m3hint">Arrastra para girar · rueda para acercar</p></div>
    <div class="m3cnc" ${view === 'cnc' ? '' : 'hidden'}><div class="m3svg"><p>Cargando plano…</p></div>
      <div class="m3dl"><button class="btn" data-dl="dxf">Descargar DXF (CNC)</button><span>Contornos de planta, alzado frontal y lateral con cotas generales en mm, tomados del modelo 3D.</span></div></div></div></div>`;
  m3el.classList.add('open');
  m3el.querySelector('.bclose').onclick = closeMob3D;
  m3el.querySelectorAll('.m3tabs button').forEach(b => b.onclick = () => openMob3D(k, b.dataset.t));
  m3el.querySelector('[data-dl]').onclick = async () => {
    const bytes = await bytesOf(p.dxf); const url = URL.createObjectURL(new Blob([bytes], { type:'application/dxf' }));
    const a = document.createElement('a'); a.href = url; a.download = `${k}.dxf`; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
  };
  if (view === 'cnc'){
    const txt = new TextDecoder().decode(await bytesOf(p.svg));
    m3el.querySelector('.m3svg').innerHTML = txt.replace(/<\?xml[^>]*>/, '').replace(/<!DOCTYPE[^>]*>/, '');
    return;
  }
  if (!m3r) m3init();
  const host = m3el.querySelector('.m3canvas'); host.appendChild(m3r.domElement);
  const size = () => { const r = host.getBoundingClientRect(); m3r.setSize(r.width, r.height, false); m3cam.aspect = r.width / Math.max(1, r.height); m3cam.updateProjectionMatrix(); };
  size();
  if (m3obj){ m3scene.remove(m3obj); m3obj = null; }
  const gltf = await new Promise((res, rej) => { bytesOf(p.glb).then(b => { const l = new GLTFLoaderM(); l.register(parser => { const orig = parser.loadImageSource.bind(parser); parser.loadImageSource = function(i, ldr){
      const img = this.json.images[i]; if (img.bufferView === undefined) return orig(i, ldr);
      return this.getDependency('bufferView', img.bufferView).then(bv => createImageBitmap(new Blob([bv], { type: img.mimeType }))).then(bmp => { const t = new THREE.Texture(bmp); t.needsUpdate = true; return t; }); }; return { name:'bm' }; });
    l.parse(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength), '', res, rej); }); });
  m3obj = gltf.scene;
  m3obj.traverse(o => { if (o.isMesh){ if (!o.geometry.attributes.normal) o.geometry.computeVertexNormals(); o.material.side = THREE.DoubleSide; } });
  m3scene.add(m3obj);
  const box = new THREE.Box3().setFromObject(m3obj), sz = box.getSize(new THREE.Vector3()), c = box.getCenter(new THREE.Vector3());
  m3el.querySelector('.m3dims').textContent = `Ancho ${Math.round(sz.x*1000)} mm · Fondo ${Math.round(sz.z*1000)} mm · Alto ${Math.round(sz.y*1000)} mm`;
  const r = Math.max(sz.x, sz.y, sz.z);
  m3ctl.target.copy(c); m3cam.position.set(c.x + r*1.1, c.y + r*0.7, c.z + r*1.3); m3ctl.update();
  cancelAnimationFrame(m3raf);
  const tick = () => { m3ctl.update(); m3r.render(m3scene, m3cam); m3raf = requestAnimationFrame(tick); };
  tick(); addEventListener('resize', size);
}
function closeMob3D(){ m3el.classList.remove('open'); cancelAnimationFrame(m3raf); }
m3el.addEventListener('click', e => { if (e.target === m3el) closeMob3D(); });
addEventListener('keydown', e => { if (e.key === 'Escape' && m3el.classList.contains('open') && document.getElementById('lightbox').style.display !== 'grid'){ e.stopImmediatePropagation(); closeMob3D(); } }, true);
document.addEventListener('click', e => { const b = e.target.closest('.mobimg button'); if (b) window.showLightbox(b.querySelector('img').src); });

// ---------- ficha completa (desde el mapa de imágenes) ----------
const ficha = $('#fichaFull');
const PX = (x, z) => [(78 - x) * 16, (80 - z) * 16];
function miniPlano(sp){
  if (sp.zona) return '<p class="empty">Ubicación en la planta por definir.</p>';
  let pts;
  if (sp.circle){ const [x, z, r] = sp.circle; pts = Array.from({ length: 32 }, (_, i) => PX(x + r*Math.cos(i/32*2*Math.PI), z + r*Math.sin(i/32*2*Math.PI))); }
  else pts = sp.poly.map(([x, z]) => PX(x, z));
  const cx = pts.reduce((a, p) => a + p[0], 0) / pts.length, cy = pts.reduce((a, p) => a + p[1], 0) / pts.length;
  return `<svg class="mini" viewBox="96 240 1240 1400" role="img" aria-label="Ubicación de ${sp.nombre} en la planta">
    <image href="${IMG.plan}" x="0" y="0" width="1440" height="1760" opacity=".55"/>
    <polygon points="${pts.map(p => p.join(',')).join(' ')}" fill="${COL[sp.mundo]}" fill-opacity=".45" stroke="${COL[sp.mundo]}" stroke-width="6"/>
    <circle cx="${cx}" cy="${cy}" r="26" fill="none" stroke="#fff" stroke-width="5"/></svg>`;
}
let fIx = 0, fId = null;
function openFicha(id){
  const sp = ZONES.find(z => z.id === id) || SPACES.find(s => s.id === id); if (!sp) return;
  fId = id; fIx = 0;
  const col = sp.zona ? ZCOL : COL[sp.mundo], fotos = (PHOTOS[id] || []).map(k => IMG[k]);
  ficha.style.setProperty('--c', col);
  const circles = (arr, kind) => arr.map((it, i) => `<button class="fc ${kind}" style="--i:${i};${kind === 'color' ? `background:${it}` : `background-image:url(${it.img})`}" title="${kind === 'color' ? it : it.nombre}"></button>`).join('');
  ficha.innerHTML = `
    <div class="fwrap">
      <div class="fgal">
        ${fotos.length ? `<div class="fhero"><img src="${fotos[0]}" alt="${sp.nombre}">${fotos.length > 1 ? '<button class="fn fp" aria-label="Anterior">‹</button><button class="fn fx" aria-label="Siguiente">›</button>' : ''}<span class="fcount">1 / ${fotos.length}</span></div>
          ${fotos.length > 1 ? `<div class="fthumbs">${fotos.map((u, i) => `<button aria-current="${i === 0}"><img src="${u}" alt=""></button>`).join('')}</div>` : ''}`
          : '<div class="fhero empty"><p>Sin fotos de este lugar todavía</p></div>'}
      </div>
      <div class="finfo">
        <button class="fclose" aria-label="Cerrar">×</button>
        <p class="fk">${sp.zona ? sp.code + ' · zona de juego' : 'MO# ' + sp.code + ' · ' + LAB[sp.mundo]}</p>
        <h2>${sp.nombre}</h2>
        ${BR[id] ? `<button class="btn fbrand">★ Ver branding · ${BR[id].map(b => b.marca).join(' / ')}</button>` : ''}
        ${sp.zona ? '' : `
        <section><h3>Colores</h3>${sp.paleta.length ? `<div class="fcs">${circles(sp.paleta, 'color')}</div><p class="fleg">${sp.paleta.join(' · ')}</p>` : '<p class="empty">Sin colores registrados.</p>'}</section>
        <section><h3>Texturas</h3>${sp.texturas.length ? `<div class="fcs">${circles(sp.texturas, 'mat')}</div><p class="fleg">${sp.texturas.map(t => t.nombre).join(' · ')}</p>` : '<p class="empty">Acabados de color liso, sin texturas.</p>'}</section>
        <section><h3>Mobiliario</h3>${mobImgs(id)}${sp.mobiliario.length ? `<ul>${sp.mobiliario.map(m => `<li>${m}</li>`).join('')}</ul>` : '<p class="empty">Sin mobiliario registrado.</p>'}</section>`}
        <section><h3>Ubicación en la planta</h3>${miniPlano(sp)}</section>
        <div class="facts">
          ${sp.zona ? '' : '<button class="btn fplan">Ver en la planta</button><button class="btn ftour">Ver en el recorrido 3D</button>'}
        </div>
        <nav class="fnav"><button class="btn fprev">← Lugar anterior</button><button class="btn fnext">Lugar siguiente →</button></nav>
      </div>
    </div>`;
  const go = i => { fIx = (i + fotos.length) % fotos.length; const im = ficha.querySelector('.fhero img'); im.style.opacity = 0;
    setTimeout(() => { im.src = fotos[fIx]; im.style.opacity = 1; }, 140);
    ficha.querySelectorAll('.fthumbs button').forEach((b, k) => b.setAttribute('aria-current', k === fIx));
    ficha.querySelector('.fcount').textContent = `${fIx + 1} / ${fotos.length}`; };
  ficha.querySelector('.fp')?.addEventListener('click', () => go(fIx - 1));
  ficha.querySelector('.fx')?.addEventListener('click', () => go(fIx + 1));
  ficha.querySelectorAll('.fthumbs button').forEach((b, i) => b.onclick = () => go(i));
  const hi = ficha.querySelector('.fhero img'); if (hi) hi.onclick = () => window.showLightbox(hi.src);
  ficha.querySelector('.fclose').onclick = closeFicha;
  ficha.querySelectorAll('.fc.color').forEach(b => b.onclick = async () => { try { await navigator.clipboard.writeText(b.title); b.classList.add('ok'); setTimeout(() => b.classList.remove('ok'), 900); } catch(_){} });
  ficha.querySelectorAll('.fc.mat').forEach(b => b.onclick = () => { const m = /url\("?(.*?)"?\)/.exec(b.style.backgroundImage); if (m) window.showLightbox(m[1]); });
  ficha.querySelector('.fplan')?.addEventListener('click', () => { closeFicha(); setMode('plan'); openLugar(id); requestAnimationFrame(() => panTo(byId(id).userData.anchor)); });
  ficha.querySelector('.fbrand')?.addEventListener('click', () => openBrand(id));
  ficha.querySelector('.ftour')?.addEventListener('click', () => { closeFicha(); window.openTour(TOUR_OF[id] || 'acceso'); });
  const ordenIds = (CATS.find(c => c.ids.includes(id)) || CATS[0]).ids, k = ordenIds.indexOf(id);
  ficha.querySelector('.fprev').onclick = () => openFicha(ordenIds[(k - 1 + ordenIds.length) % ordenIds.length]);
  ficha.querySelector('.fnext').onclick = () => openFicha(ordenIds[(k + 1) % ordenIds.length]);
  ficha.classList.add('open'); ficha.querySelector('.finfo').scrollTop = 0;
}
function closeFicha(){ ficha.classList.remove('open'); fId = null; }
ficha.addEventListener('click', e => { if (e.target === ficha) closeFicha(); });
addEventListener('keydown', e => { if (!ficha.classList.contains('open')){ if (e.key === 'Escape' && curCat && document.body.dataset.mode === 'mapa' && $('#lightbox').style.display !== 'grid') closeCat(); return; }
  if (e.key === 'Escape' && $('#lightbox').style.display !== 'grid') closeFicha();
  if (e.key === 'ArrowRight') ficha.querySelector('.fnext').click();
  if (e.key === 'ArrowLeft') ficha.querySelector('.fprev').click(); });

// ---------- modos ----------
const modeBtns = { mapa: $('#mMapa'), plan: $('#mPlan'), tour: $('#mTour'), ciclo: $('#mCiclo') };
function syncModes(){
  const m = document.body.dataset.mode;
  Object.entries(modeBtns).forEach(([k, b]) => b.setAttribute('aria-selected', k === m));
  if (m === 'plan'){ fit(); renderer.setAnimationLoop(loop); requestAnimationFrame(() => { fit(); relayout(); }); setTimeout(() => { fit(); relayout(); }, 120); } else renderer.setAnimationLoop(null);
}
addEventListener('modechange', syncModes);
const setMode = m => { if (document.body.dataset.mode === 'tour') window.closeTour(); document.body.dataset.mode = m; syncModes(); };
modeBtns.plan.onclick = () => setMode('plan');
modeBtns.mapa.onclick = () => setMode('mapa');
modeBtns.tour.onclick = () => window.openTour(selected ? (TOUR_OF[selected.userData.sp.id] || 'acceso') : 'acceso');
modeBtns.ciclo.onclick = () => { setMode('ciclo'); showDay(cur); };
syncModes();

// ---------- ciclo semanal interactivo ----------
const ICON = {
  vote:'<rect x="4" y="11" width="16" height="9" rx="1"/><path d="M8 11V5h8v6M10 8l1.5 1.5L14 7"/>',
  shield:'<path d="M12 3l7 3v5c0 5-3.5 8-7 10-3.5-2-7-5-7-10V6z"/><path d="M12 3v18M5 11h14"/>',
  cycle:'<path d="M4 12a8 8 0 0 1 14-5l2-2v6h-6l2.5-2.5A5.5 5.5 0 0 0 6.5 12M20 12a8 8 0 0 1-14 5l-2 2v-6h6l-2.5 2.5A5.5 5.5 0 0 0 17.5 12"/>',
  group:'<circle cx="12" cy="7" r="3"/><circle cx="5" cy="9" r="2.2"/><circle cx="19" cy="9" r="2.2"/><path d="M6.5 20v-2a5.5 5.5 0 0 1 11 0v2M1.5 19v-1.5a3.5 3.5 0 0 1 3.5-3.5M22.5 19v-1.5A3.5 3.5 0 0 0 19 14"/>',
  person:'<circle cx="12" cy="8" r="4"/><path d="M4 21v-1a8 8 0 0 1 16 0v1"/>',
  sad:'<circle cx="12" cy="12" r="9"/><path d="M8.5 16.5a4.5 4.5 0 0 1 7 0"/><circle cx="9" cy="10" r=".8"/><circle cx="15" cy="10" r=".8"/>',
  bars:'<rect x="3" y="14" width="4" height="7"/><rect x="10" y="9" width="4" height="12"/><rect x="17" y="3" width="4" height="18"/>',
  heart:'<path d="M12 11s-4-2.4-4-5a2.2 2.2 0 0 1 4-1.2A2.2 2.2 0 0 1 16 6c0 2.6-4 5-4 5z"/><path d="M3 15h4l4 2h4a2 2 0 0 0 0-4h-3M7 13v6l5 2 9-4"/>',
  flame:'<path d="M12 21a6 6 0 0 0 6-6c0-4-3-6-4-9-1 2-2 3-3 3 0-2-1-4-2-5 0 4-3 6-3 11a6 6 0 0 0 6 6z"/>',
  target:'<circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/>',
  swords:'<path d="M4 4l10 10M20 4L10 14M14 14l2 2-2 2-2-2M10 14l-2 2 2 2 2-2M6 18l-2 2M18 18l2 2"/>',
  refresh:'<path d="M20 12a8 8 0 1 1-3-6.2"/><path d="M20 4v5h-5"/>',
  trophy:'<path d="M7 4h10v4a5 5 0 0 1-10 0zM7 6H4a3 3 0 0 0 3 4M17 6h3a3 3 0 0 1-3 4M12 13v4M8 21h8M9 17h6"/>'
};
const ico = k => `<svg viewBox="0 0 24 24" aria-hidden="true">${ICON[k]}</svg>`;
const track = $('#cTrack'), card = $('#cCard');
let cur = 0;
CICLO.forEach((d, i) => {
  const b = document.createElement('button'); b.className = 'node'; b.style.setProperty('--dc', d.color); b.setAttribute('role','tab');
  b.innerHTML = `<span class="num">${i + 1}</span><span class="t"><b>Día ${i + 1}</b><small>${d.titulo}</small></span>`;
  b.onclick = () => showDay(i); track.appendChild(b);
});
function slots(i){
  // estado de los nominados según el día (a partir de las láminas)
  const st = [['n','',''],['n','n',''],['n','n','n'],['s','r','r'],['s','g','x']][i];
  const lab = { n:'Nominado', s:'Se salvó', r:'En riesgo', d:'Duelo', g:'Sigue', x:'Eliminado', '':'—' };
  return `<div class="slots">${st.map((s, k) => `<div class="slot ${s || 'e'}"><span>${k + 1}</span><small>${lab[s]}</small></div>`).join('')}</div>`;
}
function showDay(i){
  cur = (i + CICLO.length) % CICLO.length; const d = CICLO[cur];
  track.querySelectorAll('.node').forEach((b, k) => { b.setAttribute('aria-selected', k === cur); b.classList.toggle('past', k < cur); });
  track.style.setProperty('--p', cur / (CICLO.length - 1));
  card.style.setProperty('--dc', d.color);
  card.innerHTML = `
    <div class="scene" style="background-image:url(${IMG['escena_' + (cur + 1)]})"></div>
    <div class="cc">
      <div class="colA">
        <p class="tag">${d.lema}</p>
        <h3>${ico('group')}<span>${d.titulo}</span></h3>
        <p class="lbl">${ico('trophy')}Hito principal</p>
        <p class="hito">${d.hito}</p>
        ${d.badge ? `<span class="badge">${d.badge}</span>` : ''}
        ${slots(cur)}
      </div>
      <div class="colB">
        <p class="lbl">Consecuencia / contenido</p>
        <ul>${d.items.map(([ic, t]) => `<li>${ico(ic)}<span>${t}</span></li>`).join('')}</ul>
      </div>
    </div>
    <button class="cnav prev" aria-label="Día anterior">‹</button><button class="cnav next" aria-label="Día siguiente">›</button>`;
  card.querySelector('.prev').onclick = () => showDay(cur - 1);
  card.querySelector('.next').onclick = () => showDay(cur + 1);
  card.classList.remove('in'); void card.offsetWidth; card.classList.add('in');
  $('#cOrig').onclick = () => window.showLightbox(IMG['ciclo_' + (cur + 1)]);
}
let sx = null;
card.addEventListener('touchstart', e => { sx = e.touches[0].clientX; }, { passive:true });
card.addEventListener('touchend', e => { if (sx === null) return; const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 50) showDay(cur + (dx < 0 ? 1 : -1)); sx = null; });
showDay(0);

addEventListener('keydown', e => {
  if (e.key === 'Escape'){ if ($('#lightbox').style.display === 'grid') return; if (document.body.dataset.mode === 'plan') closeLugar(); }
  if (document.body.dataset.mode === 'ciclo' && (e.key === 'ArrowRight' || e.key === 'ArrowLeft')) showDay(cur + (e.key === 'ArrowRight' ? 1 : -1));
});
window.__plan = { open: openLugar, close: closeLugar, set3D, showDay };
