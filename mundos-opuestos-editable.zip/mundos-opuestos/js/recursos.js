// Carga de archivos. Si la página está empaquetada en un solo archivo (herramientas/empaquetar.py),
// los binarios vienen dentro de window.__BIN__; si no, se leen desde las carpetas del proyecto.
window.loadBinary = async function (path) {
  if (window.__BIN__ && window.__BIN__[path]) {
    const bin = Uint8Array.from(atob(window.__BIN__[path]), c => c.charCodeAt(0));
    return await new Response(new Blob([bin]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();
  }
  const r = await fetch(path);
  if (!r.ok) throw new Error('No se pudo cargar ' + path);
  return await r.arrayBuffer();
};
window.loadBitmap = async function (src) {
  let blob;
  if (src.startsWith('data:')) {
    const [head, b64] = src.split(','); const type = head.slice(5).split(';')[0];
    blob = new Blob([Uint8Array.from(atob(b64), c => c.charCodeAt(0))], { type });
  } else blob = await (await fetch(src)).blob();
  return await createImageBitmap(blob);
};
window.showLightbox = src => { const l = document.getElementById('lightbox'); l.querySelector('img').src = src; l.style.display = 'grid'; };
