// Recorrido 3D del set (se carga al abrir la pestaña 'Recorrido 3D').
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const AREAS = window.AREAS;
const PHOTOS = window.PHOTOS, IMG = window.IMG;
const OVERVIEW = { cam:[92,62,-8], tgt:[46,2,38] };

const $ = s => document.querySelector(s);
function initTour(startId){
const stage = $('#stage'), lstat = $('#lstat');

// ---------- renderer ----------
const renderer = new THREE.WebGLRenderer({ antialias:true, alpha:true, powerPreference:'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
stage.appendChild(renderer.domElement);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 2000);
camera.position.set(...OVERVIEW.cam);
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(...OVERVIEW.tgt);
controls.enableDamping = true; controls.dampingFactor = 0.08;
controls.maxPolarAngle = Math.PI * 0.495; controls.minDistance = 2; controls.maxDistance = 400;

scene.add(new THREE.HemisphereLight(0xf2f5ff, 0x6b5a48, 1.35));
const sun = new THREE.DirectionalLight(0xfff1dc, 2.1); sun.position.set(-60, 90, -40); scene.add(sun);
const fill = new THREE.DirectionalLight(0xa9c8ff, 0.9); fill.position.set(80, 40, 90); scene.add(fill);
const rim = new THREE.DirectionalLight(0xffb070, 0.5); rim.position.set(-80, 20, 120); scene.add(rim);
// ---------- universo oscuro ----------
const sky = new THREE.Mesh(new THREE.SphereGeometry(900, 64, 32), new THREE.ShaderMaterial({
  side: THREE.BackSide, depthWrite: false,
  uniforms: { uTime: { value: 0 } },
  vertexShader: `varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
  fragmentShader: `
    varying vec3 vDir; uniform float uTime;
    float hash(vec3 p){ p = fract(p*0.3183099 + .1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
    float noise(vec3 x){ vec3 i = floor(x), f = fract(x); f = f*f*(3.0-2.0*f);
      return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),
                 mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z); }
    float fbm(vec3 p){ float v=0., a=.5; for(int i=0;i<5;i++){ v+=a*noise(p); p*=2.03; a*=.5; } return v; }
    float stars(vec3 d, float scale, float th){ vec3 p = d*scale; vec3 c = floor(p); float h = hash(c);
      vec3 o = vec3(hash(c+1.3), hash(c+7.1), hash(c+3.7)); float dist = length(fract(p)-o);
      return step(th, h) * smoothstep(.09, 0., dist) * (0.55 + 0.45*sin(uTime*1.5 + h*60.)); }
    void main(){
      vec3 d = normalize(vDir);
      vec3 col = mix(vec3(.012,.016,.035), vec3(.03,.035,.075), smoothstep(-.3,.8,d.y));
      float n1 = fbm(d*2.2 + vec3(0.,0.,3.)), n2 = fbm(d*3.5 + vec3(5.,1.,0.));
      float band = exp(-pow(dot(d, normalize(vec3(.35,.55,-.76))),2.)*5.);
      col += vec3(.16,.24,.52) * pow(n1,3.)*1.6 * (.4+band);
      col += vec3(.42,.20,.08) * pow(n2,4.)*1.1 * (.3+band*.8);
      col += vec3(.9,.95,1.) * (stars(d,180.,.965) + stars(d,420.,.985)*.8 + stars(d,90.,.992)*1.4);
      gl_FragColor = vec4(col, 1.);
    }`
}));
sky.renderOrder = -1; renderer.setClearColor(0x000000, 0);

function resize(){
  const w = innerWidth, h = innerHeight; renderer.setSize(w, h, false); camera.aspect = w/h;
  const p = document.getElementById('panel').getBoundingClientRect();
  if (w > 760) camera.setViewOffset(w, h, (w - p.left + 16) / 2, 0, w, h);
  else camera.setViewOffset(w, h, 0, (h - p.top) / 2 - 30, w, h);
  camera.updateProjectionMatrix();
}
addEventListener('resize', resize); resize();

// ---------- load embedded models ----------
const loader = new GLTFLoader();
// Texturas: se decodifican directo desde el binario (sin URLs blob:), para que carguen en cualquier entorno
loader.register(parser => {
  const cache = {};
  const orig = parser.loadImageSource.bind(parser);
  parser.loadImageSource = function(i, ldr){
    if (cache[i]) return cache[i];
    const img = this.json.images[i];
    if (img.bufferView === undefined || typeof createImageBitmap !== 'function') return orig(i, ldr);
    cache[i] = this.getDependency('bufferView', img.bufferView)
      .then(bv => createImageBitmap(new Blob([bv], { type: img.mimeType }), { premultiplyAlpha:'none', colorSpaceConversion:'none' }))
      .then(bmp => { const t = new THREE.Texture(bmp); t.needsUpdate = true; return t; })
      .catch(err => { console.warn('textura', i, err); return orig(i, ldr); });
    return cache[i];
  };
  return { name: 'bitmap_textures' };
});
function parse(buf){ return new Promise((res, rej) => loader.parse(buf, '', res, rej)); }
function prep(root){
  root.traverse(o => {
    if (o.isMesh){
      if (!o.geometry.attributes.normal) o.geometry.computeVertexNormals();
      const m = o.material; if (m){ m.side = THREE.DoubleSide; if (m.map) m.map.anisotropy = 4; }
      o.frustumCulled = true;
    }
  });
  return root;
}
let roof = null;
// ---------- pasto en el patio del presente ----------
async function applyGrass(root){
  let patio = null;
  root.traverse(o => { if (o.isMesh && o.material && o.material.name === 'Zigzag_1K') patio = o; });
  if (!patio) return;
  const bmp = await window.loadBitmap('assets/pasto.webp');
  const tex = new THREE.Texture(bmp); tex.needsUpdate = true; tex.flipY = false;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  patio.updateMatrixWorld(true);
  const g = patio.geometry.clone(), pos = g.attributes.position, uv = new Float32Array(pos.count * 2), p = new THREE.Vector3();
  for (let i = 0; i < pos.count; i++){ p.fromBufferAttribute(pos, i).applyMatrix4(patio.matrixWorld); uv[i*2] = p.x / 5; uv[i*2+1] = p.z / 5; }
  g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  patio.geometry = g;
  patio.material = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.95, metalness: 0, side: THREE.DoubleSide,
    polygonOffset: true, polygonOffsetFactor: 2, polygonOffsetUnits: 4 });
  patio.position.y -= 0.04;
}
(async () => {
  try{
    lstat.textContent = 'Descomprimiendo el modelo…';
    const [b, r] = await Promise.all([window.loadBinary('modelo/base.glb'), window.loadBinary('modelo/techos.glb')]);
    lstat.textContent = 'Armando los dos mundos…';
    const gb = await parse(b); scene.add(prep(gb.scene));
    await applyGrass(gb.scene);
    const gr = await parse(r); roof = prep(gr.scene); scene.add(roof);
    setRoof(false);
    $('#loader').style.opacity = 0; setTimeout(() => $('#loader').remove(), 700);
    go(Math.max(0, AREAS.findIndex(a => a.id === startId)), true);
  }catch(e){ console.error(e); lstat.textContent = 'No se pudo cargar el modelo en este navegador.'; }
})();

// ---------- roof toggle ----------
let roofOn = false;
function setRoof(v){ roofOn = v; if (roof) roof.visible = v; $('#bRoof').setAttribute('aria-pressed', v); }
$('#bRoof').onclick = () => setRoof(!roofOn);

// ---------- pins ----------
const WC = { pasado:['var(--pasado)','var(--pasado-soft)','Mundo Pasado'], futuro:['var(--futuro)','var(--futuro-soft)','Mundo Futuro'], comun:['var(--comun)','var(--comun-soft)','Entre mundos'] };
const pinsEl = $('#pins');
const pins = AREAS.map((a, i) => {
  const b = document.createElement('button'); b.className = 'pin'; b.style.setProperty('--c', WC[a.mundo][0]);
  b.innerHTML = `<b>${i+1}</b><span>${a.nombre}</span>`; b.onclick = () => go(i);
  b.setAttribute('aria-label', a.nombre); pinsEl.appendChild(b); return b;
});
const list = $('#list');
AREAS.forEach((a, i) => {
  const b = document.createElement('button'); b.style.setProperty('--c', WC[a.mundo][0]);
  b.innerHTML = `<i>${i+1}</i>${a.nombre}<small>${WC[a.mundo][2]}</small>`; b.onclick = () => go(i); list.appendChild(b);
});
const v = new THREE.Vector3();
function updatePins(){
  const w = innerWidth, h = innerHeight;
  AREAS.forEach((a, i) => {
    v.set(...a.pin).project(camera);
    const vis = v.z < 1 && Math.abs(v.x) < 1.1 && Math.abs(v.y) < 1.1;
    pins[i].classList.toggle('hidden', !vis);
    if (vis) pins[i].style.transform = `translate(${(v.x*.5+.5)*w}px,${(-v.y*.5+.5)*h}px) translate(-50%,-50%)`;
  });
}

// ---------- camera tween ----------
let tw = null;
function flyTo(cam, tgt, dur = 1400){
  tw = { t0: performance.now(), dur, p0: camera.position.clone(), q0: controls.target.clone(), p1: new THREE.Vector3(...cam), q1: new THREE.Vector3(...tgt) };
}
const ease = t => t < .5 ? 4*t*t*t : 1 - Math.pow(-2*t + 2, 3)/2;

// ---------- detail panel ----------
let cur = 0;
function render(i){
  const a = AREAS[i], [c, cs, label] = WC[a.mundo];
  const panel = $('#panel'); panel.style.setProperty('--wc', c); panel.style.setProperty('--wcs', cs);
  const ph = (PHOTOS[a.id] || []).map(k => IMG[k]);
  const slots = ph.length ? ph.map((src, k) => `<img src="${src}" alt="${a.nombre}, foto ${k+1}">`).join('')
    : `<div class="slot">Foto principal de ${a.nombre.toLowerCase()}</div><div class="slot">Foto 2</div><div class="slot">Foto 3</div>`;
  $('#detail').innerHTML = `<span class="world">● ${label}</span><h2>${a.nombre}</h2>${a.desc ? `<p class="desc">${a.desc}</p>` : ""}<div class="gallery">${slots}</div>${ph.length ? '' : '<p class="note">Espacio reservado para las fotos de esta área.</p>'}`;
  $('#detail').scrollTop = 0;
  $('#detail').querySelectorAll('.gallery img').forEach(img => img.onclick = () => { $('#lightbox img').src = img.src; $('#lightbox').style.display = 'grid'; });
  $('#count').textContent = `${i+1} de ${AREAS.length}`;
  list.querySelectorAll('button').forEach((b, k) => b.setAttribute('aria-current', k === i));
  pins.forEach((p, k) => p.classList.toggle('on', k === i));
}
function go(i, instant){
  cur = (i + AREAS.length) % AREAS.length; const a = AREAS[cur];
  render(cur);
  setRoof(!!a.techo);
  flyTo(a.cam, a.tgt, instant ? 1800 : 1300);
}
$('#bPrev').onclick = () => go(cur - 1);
$('#bNext').onclick = () => go(cur + 1);
$('#bAll').onclick = () => { setRoof(true); flyTo(OVERVIEW.cam, OVERVIEW.tgt); pins.forEach(p => p.classList.remove('on')); };
$('#lightbox').onclick = () => $('#lightbox').style.display = 'none';
addEventListener('keydown', e => { if (document.body.dataset.mode !== 'tour') return; if (e.key === 'ArrowRight') go(cur + 1); if (e.key === 'ArrowLeft') go(cur - 1); if (e.key === 'Escape') $('#lightbox').style.display = 'none'; });

// ---------- loop ----------
const loop = now => {
  if (tw){
    const t = Math.min(1, (now - tw.t0)/tw.dur), k = ease(t);
    camera.position.lerpVectors(tw.p0, tw.p1, k); controls.target.lerpVectors(tw.q0, tw.q1, k);
    if (t >= 1) tw = null;
  }
  controls.update(); renderer.render(scene, camera); updatePins();
};
renderer.setAnimationLoop(loop);
window.__dbg = { camera, controls, go, setRoof, THREE, stop:()=>{tw=null} };
return { goId: id => { const i = AREAS.findIndex(a => a.id === id); go(i < 0 ? 0 : i); }, pause: () => renderer.setAnimationLoop(null), resume: () => { resize(); renderer.setAnimationLoop(loop); } };
}
let TOUR = null;
window.openTour = id => {
  document.body.dataset.mode = 'tour';
  if (!TOUR) TOUR = initTour(id); else { TOUR.resume(); if (id) TOUR.goId(id); }
  window.dispatchEvent(new Event('modechange'));
};
window.closeTour = () => { if (TOUR) TOUR.pause(); document.body.dataset.mode = 'plan'; window.dispatchEvent(new Event('modechange')); };
