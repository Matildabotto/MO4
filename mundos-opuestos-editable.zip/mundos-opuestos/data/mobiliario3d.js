// Muebles en 3D y planos CNC (DXF). MOB3D_DE indica qué muebles se muestran en cada lugar.
window.MOB3D = {
 "sillon": {
  "nombre": "Sillón circular Futuro",
  "glb": "assets/mobiliario/sillon.glb",
  "svg": "assets/mobiliario/sillon.svg",
  "dxf": "assets/mobiliario/sillon.dxf"
 },
 "cama_pasado": {
  "nombre": "Cama Pasado",
  "glb": "assets/mobiliario/cama_pasado.glb",
  "svg": "assets/mobiliario/cama_pasado.svg",
  "dxf": "assets/mobiliario/cama_pasado.dxf"
 },
 "cocina": {
  "nombre": "Cocina semicircular Futuro",
  "glb": "assets/mobiliario/cocina.glb",
  "svg": "assets/mobiliario/cocina.svg",
  "dxf": "assets/mobiliario/cocina.dxf"
 },
 "silla": {
  "nombre": "Silla Tulip Futuro",
  "glb": "assets/mobiliario/silla.glb",
  "svg": "assets/mobiliario/silla.svg",
  "dxf": "assets/mobiliario/silla.dxf"
 },
 "mesa": {
  "nombre": "Mesa comedor Futuro",
  "glb": "assets/mobiliario/mesa.glb",
  "svg": "assets/mobiliario/mesa.svg",
  "dxf": "assets/mobiliario/mesa.dxf"
 },
 "cama_futuro": {
  "nombre": "Cama Futuro",
  "glb": "assets/mobiliario/cama_futuro.glb",
  "svg": "assets/mobiliario/cama_futuro.svg",
  "dxf": "assets/mobiliario/cama_futuro.dxf"
 }
};
window.MOB3D_DE = {
 "living": [
  "sillon"
 ],
 "camas-pasado": [
  "cama_pasado"
 ],
 "cocina-futuro": [
  "cocina"
 ],
 "comedor": [
  "mesa",
  "silla"
 ],
 "camas-futuro": [
  "cama_futuro"
 ]
};
