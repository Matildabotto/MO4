// Paradas del recorrido 3D: pin = posición del marcador, cam/tgt = posición y objetivo de la cámara, techo = mostrar techos.
window.AREAS = [
 {
  "id": "acceso",
  "nombre": "Portal de acceso",
  "mundo": "comun",
  "pin": [
   18,
   9.5,
   -14
  ],
  "tgt": [
   18,
   3,
   -12
  ],
  "cam": [
   22,
   21,
   -38
  ],
  "desc": ""
 },
 {
  "id": "espejo",
  "nombre": "Espejo de agua y puente",
  "mundo": "comun",
  "pin": [
   48,
   3,
   21
  ],
  "tgt": [
   46,
   0,
   26
  ],
  "cam": [
   43.1,
   26,
   12.3
  ],
  "desc": ""
 },
 {
  "id": "portal-futuro",
  "nombre": "Portal de entrada Futuro",
  "mundo": "futuro",
  "pin": [
   55,
   8,
   29
  ],
  "tgt": [
   55,
   3,
   30
  ],
  "cam": [
   59.4,
   26,
   16.7
  ],
  "desc": ""
 },
 {
  "id": "bano-futuro",
  "nombre": "Baño Futuro",
  "mundo": "futuro",
  "pin": [
   47.5,
   4,
   31.5
  ],
  "tgt": [
   47.5,
   1.5,
   31.5
  ],
  "cam": [
   53,
   22,
   44
  ],
  "desc": ""
 },
 {
  "id": "camas-futuro",
  "nombre": "Dormitorio Futuro",
  "mundo": "futuro",
  "pin": [
   50.5,
   3,
   36
  ],
  "tgt": [
   50.5,
   1,
   36
  ],
  "cam": [
   51.3,
   26,
   22.0
  ],
  "desc": ""
 },
 {
  "id": "camas-pasado",
  "nombre": "Dormitorio Pasado",
  "mundo": "pasado",
  "pin": [
   44,
   3,
   39
  ],
  "tgt": [
   44,
   1,
   39
  ],
  "cam": [
   34.1,
   26,
   29.1
  ],
  "desc": ""
 },
 {
  "id": "living",
  "nombre": "Living circular Futuro",
  "mundo": "futuro",
  "pin": [
   51.7,
   2.5,
   44
  ],
  "tgt": [
   51.7,
   0.5,
   44
  ],
  "cam": [
   51.7,
   26,
   30.0
  ],
  "desc": ""
 },
 {
  "id": "cocina-futuro",
  "nombre": "Cocina Futuro",
  "mundo": "futuro",
  "pin": [
   61.5,
   4,
   47.5
  ],
  "tgt": [
   61,
   1.5,
   47.5
  ],
  "cam": [
   74.7,
   26,
   50.6
  ],
  "desc": ""
 },
 {
  "id": "estar",
  "nombre": "Estar exterior",
  "mundo": "futuro",
  "pin": [
   62,
   3.5,
   40
  ],
  "tgt": [
   62,
   1.5,
   40
  ],
  "cam": [
   74.9,
   26,
   34.6
  ],
  "desc": ""
 },
 {
  "id": "comedor",
  "nombre": "Comedor Futuro",
  "mundo": "futuro",
  "pin": [
   53.8,
   3,
   49.7
  ],
  "tgt": [
   53.8,
   1,
   49.7
  ],
  "cam": [
   62.6,
   26,
   60.6
  ],
  "desc": ""
 },
 {
  "id": "arbol",
  "nombre": "Árbol central",
  "mundo": "comun",
  "pin": [
   43,
   17,
   48
  ],
  "tgt": [
   43,
   8,
   48
  ],
  "cam": [
   14,
   18,
   28
  ],
  "techo": true,
  "desc": ""
 },
 {
  "id": "rollizos",
  "nombre": "Baño Pasado",
  "mundo": "pasado",
  "pin": [
   33.5,
   6,
   42
  ],
  "tgt": [
   33.5,
   1,
   42
  ],
  "cam": [
   19.7,
   26,
   39.5
  ],
  "desc": ""
 }
];
