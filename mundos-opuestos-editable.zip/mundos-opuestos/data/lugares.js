// Lugares de la planta: nombre, mundo (pasado/futuro/presente), forma en la planta (poly = puntos x,z en metros; circle = [x, z, radio]), paleta, texturas y mobiliario.
window.SPACES = [
 {
  "id": "patio",
  "nombre": "Patio del Presente",
  "mundo": "presente",
  "h": 0.25,
  "poly": [
   [
    24,
    -19
   ],
   [
    35,
    -20.5
   ],
   [
    46,
    -18.5
   ],
   [
    56,
    -13.5
   ],
   [
    64,
    -7.5
   ],
   [
    68,
    -1
   ],
   [
    69,
    8
   ],
   [
    67.5,
    16
   ],
   [
    63,
    22.5
   ],
   [
    56,
    20
   ],
   [
    47,
    19.5
   ],
   [
    40,
    21
   ],
   [
    34,
    25
   ],
   [
    28,
    30
   ],
   [
    18,
    31.5
   ],
   [
    10.5,
    30.5
   ],
   [
    10.5,
    -2.5
   ],
   [
    8,
    -6.5
   ],
   [
    5,
    -4
   ],
   [
    12,
    -10
   ],
   [
    18,
    -15.5
   ]
  ],
  "paleta": [
   "#4C782E",
   "#739E47",
   "#FCFCFC",
   "#3D3D3D",
   "#A59794"
  ],
  "texturas": [
   {
    "nombre": "Pasto",
    "img": "assets/texturas/pasto-6734f3.webp"
   },
   {
    "nombre": "Mármol",
    "img": "assets/texturas/marmol-133d3f.webp"
   },
   {
    "nombre": "Pavimento zigzag",
    "img": "assets/texturas/pavimento-zigzag-f56dc4.webp"
   },
   {
    "nombre": "Acero de portón",
    "img": "assets/texturas/acero-de-porton-9c0bf9.webp"
   }
  ],
  "mobiliario": [
   "Portón de truss metálico de acceso",
   "Reja perimetral modular de 10 m de alto",
   "Pasto"
  ]
 },
 {
  "id": "piscina",
  "nombre": "Piscina",
  "mundo": "presente",
  "h": 0.5,
  "poly": [
   [
    0.3,
    27
   ],
   [
    9.9,
    27
   ],
   [
    9.9,
    -1.8
   ],
   [
    7.5,
    -1.8
   ],
   [
    7.5,
    -5.3
   ],
   [
    2.5,
    -5.3
   ],
   [
    2.5,
    -1.8
   ],
   [
    0.3,
    -1.8
   ]
  ],
  "paleta": [
   "#CAFFFF",
   "#A59794",
   "#CBFF78"
  ],
  "texturas": [
   {
    "nombre": "Mármol",
    "img": "assets/texturas/marmol-133d3f.webp"
   }
  ],
  "mobiliario": [
   "Piscina de la sede"
  ]
 },
 {
  "id": "porton",
  "nombre": "Portón de acceso",
  "mundo": "presente",
  "h": 1.6,
  "poly": [
   [
    24.3,
    -15
   ],
   [
    22.9,
    -17.6
   ],
   [
    12.3,
    -11.6
   ],
   [
    13.7,
    -9
   ]
  ],
  "paleta": [
   "#3D3D3D",
   "#E0E0E0",
   "#794625",
   "#1F1F1F",
   "#9E7565"
  ],
  "texturas": [
   {
    "nombre": "Acero de portón",
    "img": "assets/texturas/acero-de-porton-9c0bf9.webp"
   },
   {
    "nombre": "Enchapado de madera",
    "img": "assets/texturas/enchapado-de-madera-28ed10.webp"
   },
   {
    "nombre": "Rejilla metálica",
    "img": "assets/texturas/rejilla-metalica-f2bee0.webp"
   },
   {
    "nombre": "Corteza de pino",
    "img": "assets/texturas/corteza-de-pino-a96344.webp"
   }
  ],
  "mobiliario": [
   "Portón con estructura de truss",
   "Marco y rejilla metálica",
   "Puertas de acero"
  ]
 },
 {
  "id": "espejo",
  "nombre": "Espejo de agua",
  "mundo": "presente",
  "h": 0.4,
  "poly": [
   [
    37,
    23.5
   ],
   [
    42,
    21
   ],
   [
    49,
    20.4
   ],
   [
    56,
    20.6
   ],
   [
    62,
    22.2
   ],
   [
    65,
    24.6
   ],
   [
    60,
    27.5
   ],
   [
    53.5,
    29.5
   ],
   [
    47,
    30.2
   ],
   [
    41,
    30.5
   ],
   [
    36.5,
    33
   ],
   [
    33,
    36
   ],
   [
    30.5,
    33.5
   ],
   [
    33,
    27
   ]
  ],
  "paleta": [
   "#00FFFF",
   "#A78561",
   "#F9F9FF",
   "#929292",
   "#CFD6DD"
  ],
  "texturas": [
   {
    "nombre": "Ramas secas",
    "img": "assets/texturas/ramas-secas-6f3852.webp"
   },
   {
    "nombre": "Piedra",
    "img": "assets/texturas/piedra-a45b37.webp"
   },
   {
    "nombre": "Vidrio de seguridad",
    "img": "assets/texturas/vidrio-de-seguridad-2bb186.webp"
   }
  ],
  "mobiliario": [
   "Lámina de agua",
   "Piedras y ramas de borde"
  ]
 },
 {
  "id": "puente-futuro",
  "nombre": "Puente del Futuro",
  "mundo": "futuro",
  "h": 1.2,
  "poly": [
   [
    54.3,
    27.9
   ],
   [
    55.5,
    26.9
   ],
   [
    47.8,
    20.1
   ],
   [
    46.6,
    21.1
   ]
  ],
  "paleta": [
   "#F9F9FF",
   "#CDECF4",
   "#767C7D",
   "#CECECE"
  ],
  "texturas": [
   {
    "nombre": "Vidrio de seguridad",
    "img": "assets/texturas/vidrio-de-seguridad-2bb186.webp"
   },
   {
    "nombre": "Metal cepillado",
    "img": "assets/texturas/metal-cepillado-c50391.webp"
   },
   {
    "nombre": "Metal perforado",
    "img": "assets/texturas/metal-perforado-a2c269.webp"
   }
  ],
  "mobiliario": [
   "Rampla de acceso Futuro",
   "Baranda de vidrio de seguridad",
   "Marco de acceso con arcos triangulares"
  ]
 },
 {
  "id": "puente-pasado",
  "nombre": "Puente del Pasado",
  "mundo": "pasado",
  "h": 1.2,
  "poly": [
   [
    32.6,
    41.5
   ],
   [
    38.9,
    41.5
   ],
   [
    37.4,
    18.6
   ],
   [
    33,
    18.6
   ]
  ],
  "paleta": [
   "#866E5D",
   "#A78561",
   "#46443F",
   "#6D5C49",
   "#CFD6DD"
  ],
  "texturas": [
   {
    "nombre": "Varas finas",
    "img": "assets/texturas/varas-finas-a8cc00.webp"
   },
   {
    "nombre": "Ramas secas",
    "img": "assets/texturas/ramas-secas-6f3852.webp"
   },
   {
    "nombre": "Tablones de madera",
    "img": "assets/texturas/tablones-de-madera-f2c7f7.webp"
   },
   {
    "nombre": "Ramas de árbol",
    "img": "assets/texturas/ramas-de-arbol-2b281d.webp"
   }
  ],
  "mobiliario": [
   "Pasarela de tablones de madera",
   "Bordes de ramas y varas"
  ]
 },
 {
  "id": "portal-futuro",
  "nombre": "Entrada Futuro",
  "mundo": "futuro",
  "h": 1.4,
  "poly": [
   [
    53.2,
    33.3
   ],
   [
    60.6,
    33.3
   ],
   [
    61,
    26
   ],
   [
    53.5,
    25.2
   ]
  ],
  "paleta": [
   "#F9F9FF",
   "#767C7D",
   "#CECECE",
   "#CDECF4",
   "#E67B00"
  ],
  "texturas": [
   {
    "nombre": "Metal cepillado",
    "img": "assets/texturas/metal-cepillado-c50391.webp"
   },
   {
    "nombre": "Metal perforado",
    "img": "assets/texturas/metal-perforado-a2c269.webp"
   },
   {
    "nombre": "Vidrio de seguridad",
    "img": "assets/texturas/vidrio-de-seguridad-2bb186.webp"
   }
  ],
  "mobiliario": [
   "Portal de arcos triangulares",
   "Muros curvos de acceso",
   "Puerta con malla metálica"
  ]
 },
 {
  "id": "bano-futuro",
  "nombre": "Baño Futuro",
  "mundo": "futuro",
  "h": 1.0,
  "poly": [
   [
    45.6,
    33.3
   ],
   [
    52.8,
    33.3
   ],
   [
    52.8,
    29.9
   ],
   [
    45,
    29.9
   ]
  ],
  "paleta": [
   "#FFFFFF",
   "#CFD6DD",
   "#BABABA",
   "#73E158"
  ],
  "texturas": [
   {
    "nombre": "Gráfica de baño",
    "img": "assets/texturas/grafica-de-bano-7a6366.webp"
   },
   {
    "nombre": "Espejo",
    "img": "assets/texturas/espejo-96520d.webp"
   },
   {
    "nombre": "Aluminio anodizado",
    "img": "assets/texturas/aluminio-anodizado-de1d5e.webp"
   }
  ],
  "mobiliario": [
   "2 WC Duravit Starck 3 con estanque Geberit Kappa",
   "Ducha con set completo",
   "Mueble con espejo"
  ]
 },
 {
  "id": "camas-futuro",
  "nombre": "Dormitorio Futuro",
  "mundo": "futuro",
  "h": 1.0,
  "poly": [
   [
    48.6,
    39.8
   ],
   [
    57,
    39.8
   ],
   [
    57,
    33.6
   ],
   [
    48.6,
    33.6
   ]
  ],
  "paleta": [
   "#F9F9FF",
   "#E6A800",
   "#FFCACA",
   "#E6E6E6",
   "#7A7AFF"
  ],
  "texturas": [],
  "mobiliario": [
   "10 camas (2 filas de 5)",
   "Muro curvo de habitación"
  ]
 },
 {
  "id": "estar",
  "nombre": "Estar exterior",
  "mundo": "futuro",
  "h": 0.9,
  "poly": [
   [
    60.2,
    43
   ],
   [
    65,
    43
   ],
   [
    64.6,
    37
   ],
   [
    60.2,
    37.4
   ]
  ],
  "paleta": [
   "#B28757",
   "#FFFFFF",
   "#EBE1BB",
   "#402E7E",
   "#6B6B6B"
  ],
  "texturas": [],
  "mobiliario": [
   "2 sofás con chaise longue",
   "Cojines de tela",
   "Estructura de madera y cuerda"
  ]
 },
 {
  "id": "living",
  "nombre": "Living circular",
  "mundo": "futuro",
  "h": 0.9,
  "circle": [
   51.6,
   44.4,
   4.4
  ],
  "paleta": [
   "#FFF9FD",
   "#CFD6DD",
   "#73E158",
   "#C4AF7B",
   "#93CA00"
  ],
  "texturas": [
   {
    "nombre": "Metal satinado",
    "img": "assets/texturas/metal-satinado-d282d6.webp"
   },
   {
    "nombre": "Espejo",
    "img": "assets/texturas/espejo-96520d.webp"
   },
   {
    "nombre": "Metal oscuro",
    "img": "assets/texturas/metal-oscuro-9d5c89.webp"
   }
  ],
  "mobiliario": [
   "Sofá circular con cojines"
  ]
 },
 {
  "id": "comedor",
  "nombre": "Comedor Futuro",
  "mundo": "futuro",
  "h": 0.9,
  "poly": [
   [
    55.2,
    53.8
   ],
   [
    59.8,
    53.8
   ],
   [
    59.8,
    47.4
   ],
   [
    53.3,
    47.4
   ]
  ],
  "paleta": [
   "#FFFFFF",
   "#EFB3A0"
  ],
  "texturas": [],
  "mobiliario": [
   "Mesa de comedor Futuro",
   "10 sillas Tulip"
  ]
 },
 {
  "id": "cocina-futuro",
  "nombre": "Cocina Futuro",
  "mundo": "futuro",
  "h": 1.0,
  "poly": [
   [
    60.4,
    52.4
   ],
   [
    63.8,
    51.8
   ],
   [
    65.8,
    48
   ],
   [
    65.8,
    43.4
   ],
   [
    61.4,
    43.4
   ],
   [
    60.4,
    46.5
   ]
  ],
  "paleta": [
   "#0000A8",
   "#FFFFFF",
   "#7B8F98",
   "#B2692B",
   "#BBBBBB"
  ],
  "texturas": [
   {
    "nombre": "Azulejo de vidrio",
    "img": "assets/texturas/azulejo-de-vidrio-90801a.webp"
   },
   {
    "nombre": "Piedra veteada gris",
    "img": "assets/texturas/piedra-veteada-gris-b9163b.webp"
   },
   {
    "nombre": "Bambú",
    "img": "assets/texturas/bambu-c6daf8.webp"
   }
  ],
  "mobiliario": [
   "Cocina semicircular en mosaico azul y mármol",
   "Refrigerador Samsung",
   "Encimera GE con campana de vidrio",
   "Lavaplatos con grifería extensible"
  ]
 },
 {
  "id": "jardin-futuro",
  "nombre": "Jardín del Futuro",
  "mundo": "futuro",
  "h": 0.6,
  "poly": [
   [
    56.4,
    61
   ],
   [
    60.5,
    58.5
   ],
   [
    63.5,
    54.5
   ],
   [
    60,
    54.2
   ],
   [
    56,
    54.2
   ]
  ],
  "paleta": [
   "#E6FFE6",
   "#93CA00"
  ],
  "texturas": [],
  "mobiliario": []
 },
 {
  "id": "camas-pasado",
  "nombre": "Dormitorio Pasado",
  "mundo": "pasado",
  "h": 1.0,
  "poly": [
   [
    40.2,
    43.2
   ],
   [
    47.9,
    43.2
   ],
   [
    47.9,
    35.8
   ],
   [
    40.2,
    35.8
   ]
  ],
  "paleta": [
   "#6D5C49",
   "#000000",
   "#C7A384",
   "#46443F",
   "#967D68"
  ],
  "texturas": [
   {
    "nombre": "Ramas de árbol",
    "img": "assets/texturas/ramas-de-arbol-2b281d.webp"
   },
   {
    "nombre": "Tallo",
    "img": "assets/texturas/tallo-a43e83.webp"
   },
   {
    "nombre": "Piel / manta",
    "img": "assets/texturas/piel-manta-da801f.webp"
   },
   {
    "nombre": "Tablones de madera",
    "img": "assets/texturas/tablones-de-madera-f2c7f7.webp"
   }
  ],
  "mobiliario": [
   "10 camas rústicas con pieles y mantas",
   "Estructura de ramas"
  ]
 },
 {
  "id": "arbol",
  "nombre": "Árbol central",
  "mundo": "pasado",
  "h": 1.4,
  "circle": [
   44.2,
   47.6,
   3.9
  ],
  "paleta": [
   "#272A0B",
   "#93704D",
   "#A78561",
   "#634F48"
  ],
  "texturas": [
   {
    "nombre": "Follaje",
    "img": "assets/texturas/follaje-5da055.webp"
   },
   {
    "nombre": "Piso de madera del Pasado",
    "img": "assets/texturas/piso-de-madera-del-pasado-3692df.webp"
   },
   {
    "nombre": "Césped",
    "img": "assets/texturas/cesped-a5ed05.webp"
   },
   {
    "nombre": "Corteza",
    "img": "assets/texturas/corteza-763cd4.webp"
   }
  ],
  "mobiliario": [
   "Árbol central con tronco y ramas esculturales",
   "Follaje de gran escala"
  ]
 },
 {
  "id": "explanada",
  "nombre": "Explanada del Pasado",
  "mundo": "pasado",
  "h": 0.7,
  "poly": [
   [
    40.2,
    56.6
   ],
   [
    45,
    59.6
   ],
   [
    52.8,
    60.2
   ],
   [
    55.3,
    57.2
   ],
   [
    53.4,
    52
   ],
   [
    40.4,
    52
   ]
  ],
  "paleta": [
   "#A78561",
   "#866E5D",
   "#F9F9FF",
   "#634F48"
  ],
  "texturas": [
   {
    "nombre": "Ramas secas",
    "img": "assets/texturas/ramas-secas-6f3852.webp"
   },
   {
    "nombre": "Varas finas",
    "img": "assets/texturas/varas-finas-a8cc00.webp"
   },
   {
    "nombre": "Tallo",
    "img": "assets/texturas/tallo-a43e83.webp"
   },
   {
    "nombre": "Piso de madera del Pasado",
    "img": "assets/texturas/piso-de-madera-del-pasado-3692df.webp"
   }
  ],
  "mobiliario": [
   "Piso de madera del Pasado",
   "Esculturas de ramas",
   "Bordes de varas secas"
  ]
 },
 {
  "id": "rollizos",
  "nombre": "Baño Pasado",
  "mundo": "pasado",
  "h": 1.2,
  "poly": [
   [
    33.4,
    38
   ],
   [
    40.4,
    37
   ],
   [
    41.2,
    31.4
   ],
   [
    34,
    30.4
   ]
  ],
  "paleta": [
   "#A78561",
   "#6D5C49",
   "#46443F",
   "#CFD6DD",
   "#929292"
  ],
  "texturas": [
   {
    "nombre": "Ramas secas",
    "img": "assets/texturas/ramas-secas-6f3852.webp"
   },
   {
    "nombre": "Ramas de árbol",
    "img": "assets/texturas/ramas-de-arbol-2b281d.webp"
   },
   {
    "nombre": "Tablones de madera",
    "img": "assets/texturas/tablones-de-madera-f2c7f7.webp"
   },
   {
    "nombre": "Tronco",
    "img": "assets/texturas/tronco-1deb92.webp"
   }
  ],
  "mobiliario": [
   "Cerramiento de ramas esculturales",
   "Palos rollizos",
   "Tablones de madera"
  ]
 },
 {
  "id": "z-cara",
  "nombre": "Zona cara a cara",
  "mundo": "presente",
  "h": 0.6,
  "circle": [
   36.2,
   11.5,
   10
  ],
  "paleta": [
   "#FFFFFF"
  ],
  "texturas": [],
  "mobiliario": [
   "Bancas curvas enfrentadas, una por equipo",
   "Plataformas circulares al centro"
  ]
 }
];
