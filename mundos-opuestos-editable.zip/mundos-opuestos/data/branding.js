// Branding por lugar: marca, color, imágenes de referencia (claves de IMG) y elementos de marca. Los lugares que aparecen aquí muestran el botón "Ver branding".
window.BRANDING = {
 "bano-futuro": [
  {
   "marca": "Cruz Verde",
   "color": "#1FA35C",
   "imgs": [
    "brand_cv1",
    "brand_cv2"
   ],
   "elementos": [
    "Toallas con el logo sobre el mueble del lavamanos",
    "Productos de higiene de la marca en el lavamanos, la repisa de la ducha y la banca",
    "Franja de muro en el verde de la marca",
    "Toallas dobladas con logo junto a la ducha"
   ]
  }
 ],
 "camas-futuro": [
  {
   "marca": "Hites",
   "color": "#2F6FD6",
   "imgs": [
    "brand_hites"
   ],
   "elementos": [
    "Cojín con logo en cada cama",
    "Piecera (cubrecama) con logo en cada cama",
    "Panel de marca junto al clóset con toallas y ropa de cama"
   ]
  },
  {
   "marca": "Cruz Verde",
   "color": "#1FA35C",
   "imgs": [
    "brand_cv2",
    "brand_cv1"
   ],
   "elementos": [
    "Ropa de cama en celeste junto al baño brandeado",
    "Toallas y productos de la marca en el lavamanos del dormitorio"
   ]
  }
 ],
 "living": [
  {
   "marca": "Banco de Chile",
   "color": "#1F4FC1",
   "imgs": [
    "brand_bch"
   ],
   "elementos": [
    "Cojines azules con el logo en el sofá circular",
    "Cojines en la paleta de la marca (azul y celeste)"
   ]
  }
 ],
 "comedor": [
  {
   "marca": "Banco de Chile",
   "color": "#1F4FC1",
   "imgs": [
    "brand_bch"
   ],
   "elementos": [
    "Sillas del comedor en el azul de la marca",
    "Comedor integrado a la vista del living con cojines de la marca"
   ]
  }
 ]
};
