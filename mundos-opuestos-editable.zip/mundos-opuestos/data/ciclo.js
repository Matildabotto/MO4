// Ciclo semanal: un objeto por día. items = [icono, texto]. Iconos: vote, shield, cycle, group, person, sad, bars, heart, flame, target, swords, refresh.
window.CICLO = [
 {
  "color": "#22E3B0",
  "lema": "Dos equipos / un solo camino",
  "titulo": "Competencia por equipos",
  "hito": "Define qué equipo vive en el futuro y cuál queda en el pasado. Se define el primer nominado.",
  "badge": "Primer nominado",
  "items": [
   [
    "vote",
    "El equipo ganador vota en secreto e individualmente por un integrante del equipo perdedor para nominarlo."
   ],
   [
    "shield",
    "El equipo perdedor puede <b>bloquear o proteger</b> a un integrante antes de la votación."
   ],
   [
    "cycle",
    "Si el más votado está protegido, el segundo más votado es el nominado."
   ],
   [
    "group",
    "Si hay empate, el equipo perdedor debe decidir nuevamente entre los empatados."
   ]
  ]
 },
 {
  "color": "#B04CFF",
  "lema": "El pasado también desafía",
  "titulo": "Competencia individual del pasado",
  "hito": "Quien gana puede transitar entre ambos mundos. El perdedor se convierte en el segundo nominado.",
  "badge": "Segundo nominado",
  "items": [
   [
    "person",
    "Quien pierde <b>queda automáticamente como segundo nominado.</b>"
   ],
   [
    "sad",
    "El nominado del pasado no participa en la fiesta: queda solo y aislado, <b>lo que genera un fuerte contenido emocional.</b>"
   ],
   [
    "bars",
    "La prueba exige esfuerzo real para evitar que los participantes abandonen la competencia."
   ]
  ]
 },
 {
  "color": "#FF3DAE",
  "lema": "Conexión / emoción / decisión",
  "titulo": "Cara a cara + bienestar",
  "hito": "Durante el día se realiza el cara a cara que define al tercer nominado. Posteriormente existe un juego de bienestar para los integrantes del equipo del futuro.",
  "badge": "Tercer nominado",
  "items": [
   [
    "heart",
    "En la noche se realiza el cara a cara, que <b>define al tercer nominado</b> y genera confrontación directa."
   ],
   [
    "flame",
    "Une bienestar, emoción y tensión para hacer avanzar la historia de la semana."
   ]
  ]
 },
 {
  "color": "#FF8A1F",
  "lema": "Uno se salva / dos en riesgo",
  "titulo": "Competencia de salvación",
  "hito": "Compiten los nominados. Uno se salva y dos quedan en riesgo para el duelo.",
  "badge": "",
  "items": [
   [
    "target",
    "<b>Mantiene la tensión competitiva</b> y prepara el conflicto final de la semana."
   ]
  ]
 },
 {
  "color": "#22E0D0",
  "lema": "Un ciclo termina / otro comienza",
  "titulo": "Duelo / eliminación",
  "hito": "Los dos nominados finales se enfrentan.",
  "badge": "Un eliminado",
  "items": [
   [
    "swords",
    "<b>La eliminación cierra el ciclo semanal</b> y deja instalado el punto de partida para la semana siguiente."
   ],
   [
    "refresh",
    "Refuerza la idea de que cada decisión cuenta y nada está asegurado."
   ]
  ]
 }
];
