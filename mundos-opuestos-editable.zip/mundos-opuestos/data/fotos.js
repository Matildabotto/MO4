// Rutas de todas las imágenes. La clave se usa en PHOTOS (abajo) y en el código.
window.IMG = {
 "frontis_pano": "assets/fotos/frontis_pano.webp",
 "frontis_1": "assets/fotos/frontis_1.webp",
 "frontis_2": "assets/fotos/frontis_2.webp",
 "frontis_3": "assets/fotos/frontis_3.webp",
 "frontis_0": "assets/fotos/frontis_0.webp",
 "frontis_porton": "assets/fotos/frontis_porton.webp",
 "frontis_noche": "assets/fotos/frontis_noche.webp",
 "futuro_living": "assets/fotos/futuro_living.webp",
 "futuro_sofa": "assets/fotos/futuro_sofa.webp",
 "futuro_tumbonas": "assets/fotos/futuro_tumbonas.webp",
 "futuro_sofa2": "assets/fotos/futuro_sofa2.webp",
 "pasado_camas1": "assets/fotos/pasado_camas1.webp",
 "pasado_camas2": "assets/fotos/pasado_camas2.webp",
 "pasado_camas3": "assets/fotos/pasado_camas3.webp",
 "pasado_circulo": "assets/fotos/pasado_circulo.webp",
 "pasado_banca2": "assets/fotos/pasado_banca2.webp",
 "pasado_fogon": "assets/fotos/pasado_fogon.webp",
 "contraste_camas": "assets/fotos/contraste_camas.webp",
 "contraste_living": "assets/fotos/contraste_living.webp",
 "cara_1": "assets/fotos/cara_1.webp",
 "cara_2": "assets/fotos/cara_2.webp",
 "comp_1": "assets/fotos/comp_1.webp",
 "comp_2": "assets/fotos/comp_2.webp",
 "comp_3": "assets/fotos/comp_3.webp",
 "duelo_1": "assets/fotos/duelo_1.webp",
 "duelo_2": "assets/fotos/duelo_2.webp",
 "brand_cv1": "assets/fotos/brand_cv1.webp",
 "brand_cv2": "assets/fotos/brand_cv2.webp",
 "brand_hites": "assets/fotos/brand_hites.webp",
 "brand_bch": "assets/fotos/brand_bch.webp",
 "futuro_cocina": "assets/fotos/futuro_cocina.webp",
 "futuro_dorm1": "assets/fotos/futuro_dorm1.webp",
 "futuro_dorm2": "assets/fotos/futuro_dorm2.webp",
 "futuro_comedor": "assets/fotos/futuro_comedor.webp",
 "mob_cocina": "assets/fotos/mob_cocina.webp",
 "mob_mesa": "assets/fotos/mob_mesa.webp",
 "mob_mesa2": "assets/fotos/mob_mesa2.webp",
 "mob_sillon": "assets/fotos/mob_sillon.webp",
 "mob_cama_pasado": "assets/fotos/mob_cama_pasado.webp",
 "mob_portal": "assets/fotos/mob_portal.webp",
 "ciclo_1": "assets/ciclo/lamina-dia-1.webp",
 "escena_1": "assets/ciclo/escena-dia-1.webp",
 "ciclo_2": "assets/ciclo/lamina-dia-2.webp",
 "escena_2": "assets/ciclo/escena-dia-2.webp",
 "ciclo_3": "assets/ciclo/lamina-dia-3.webp",
 "escena_3": "assets/ciclo/escena-dia-3.webp",
 "ciclo_4": "assets/ciclo/lamina-dia-4.webp",
 "escena_4": "assets/ciclo/escena-dia-4.webp",
 "ciclo_5": "assets/ciclo/lamina-dia-5.webp",
 "escena_5": "assets/ciclo/escena-dia-5.webp",
 "plan": "assets/planta.webp"
};

// Imágenes de mobiliario (recortes) que aparecen en la sección Mobiliario de cada lugar.
window.MOBIMG = {
 "cocina-futuro": [
  "mob_cocina"
 ],
 "comedor": [
  "mob_mesa",
  "mob_mesa2"
 ],
 "living": [
  "mob_sillon"
 ],
 "camas-pasado": [
  "mob_cama_pasado"
 ],
 "porton": [
  "mob_portal"
 ]
};

// Fotos de cada lugar (la primera es la que aparece al pasar el mouse y en el mapa). Las claves 'z-...' son las zonas de juego.
window.PHOTOS = {
 "patio": [
  "frontis_pano",
  "frontis_noche",
  "frontis_2",
  "frontis_3"
 ],
 "porton": [
  "frontis_porton"
 ],
 "piscina": [
  "frontis_porton"
 ],
 "espejo": [
  "frontis_0",
  "frontis_1"
 ],
 "puente-futuro": [
  "frontis_1"
 ],
 "puente-pasado": [
  "frontis_0"
 ],
 "portal-futuro": [
  "frontis_1"
 ],
 "camas-pasado": [
  "pasado_camas3",
  "pasado_camas1",
  "pasado_camas2"
 ],
 "camas-futuro": [
  "futuro_dorm2",
  "futuro_dorm1",
  "contraste_camas"
 ],
 "living": [
  "futuro_living",
  "futuro_comedor",
  "contraste_living"
 ],
 "estar": [
  "futuro_sofa",
  "futuro_sofa2"
 ],
 "jardin-futuro": [
  "futuro_tumbonas"
 ],
 "comedor": [
  "futuro_comedor",
  "futuro_tumbonas"
 ],
 "cocina-futuro": [
  "futuro_cocina"
 ],
 "bano-futuro": [
  "futuro_dorm1",
  "futuro_dorm2"
 ],
 "explanada": [
  "pasado_fogon",
  "pasado_banca2"
 ],
 "arbol": [
  "pasado_circulo",
  "pasado_banca2"
 ],
 "z-competencia": [
  "comp_1",
  "comp_2",
  "comp_3"
 ],
 "z-duelo": [
  "duelo_1",
  "duelo_2"
 ],
 "z-cara": [
  "cara_1",
  "cara_2"
 ],
 "acceso": [
  "frontis_pano",
  "frontis_noche",
  "frontis_2",
  "frontis_3"
 ]
};
