# Mundos Opuestos · Set del reality

Mapa de imágenes, planta interactiva 2D/3D, fichas de cada lugar, zonas de juego, ciclo semanal y recorrido 3D del set.
Producción: Cooking Media.

## Estructura

```
index.html              Página principal (estructura y textos fijos de la interfaz)
css/estilos.css         Todos los estilos (colores, tamaños, tipografías)
js/planta.js            Mapa de imágenes, planta, rótulos, fichas, índice de lugares y ciclo semanal
js/recorrido.js         Recorrido 3D
js/recursos.js          Carga de archivos (no hace falta tocarlo)
data/lugares.js         Lugares de la planta: nombre, mundo, forma, colores, texturas y mobiliario
data/fotos.js           Rutas de las imágenes (IMG) y fotos asignadas a cada lugar (PHOTOS)
data/ciclo.js           Textos del ciclo semanal (días 1 a 5)
data/branding.js        Branding por lugar (marcas, imágenes de referencia y elementos)
data/mobiliario3d.js    Muebles en 3D (assets/mobiliario/*.glb) y sus planos CNC (*.dxf, *.pdf, *.svg)
data/recorrido.js       Paradas del recorrido 3D (nombre y posición de cámara)
assets/                 Imágenes: fotos, láminas del ciclo, texturas, planta, logo, fondo, pasto
modelo/base.glb         Modelo 3D del set (sin techos)
modelo/techos.glb       Techos, lona, follaje y ramas altas (se ocultan al entrar a cada área)
herramientas/           Empaquetador en un solo archivo, con o sin clave
```

## Cambios frecuentes

**Cambiar el nombre de un lugar:** en `data/lugares.js`, editar `"nombre"` del lugar. Si también está en el recorrido 3D, cambiarlo en `data/recorrido.js`.

**Agregar o cambiar fotos de un lugar:**
1. Copiar la imagen a `assets/fotos/` (ideal: .webp o .jpg de unos 1100 px de ancho).
2. En `data/fotos.js`, agregarla a `window.IMG`, por ejemplo `"cocina_1": "assets/fotos/cocina_1.webp"`.
3. En `window.PHOTOS`, agregar la clave al lugar: `"cocina-futuro": ["cocina_1"]`. La primera foto es la que aparece al pasar el mouse.

**Zonas de juego (Zona de competencia, Zona de duelo, Zona cara a cara):** sus fotos están en `PHOTOS` bajo `z-competencia`, `z-duelo` y `z-cara`. Los nombres se editan en `js/planta.js` (buscar `const ZONES`).

**Colores, texturas o mobiliario de un lugar:** en `data/lugares.js`, listas `"paleta"` (códigos hex), `"texturas"` (nombre + imagen en `assets/texturas/`) y `"mobiliario"`.

**Portada y grupos del mapa:** en `js/planta.js`, buscar `const CATS`. Cada grupo (Mundo Futuro, Mundo Pasado, Patio del Presente, Zonas de juego) tiene su imagen de portada (`cover`), su encuadre (`pos`) y la lista de lugares (`ids`) en el orden en que aparecen.

**Encuadre de la foto en el mapa:** en `js/planta.js`, `const FOCUS` define qué parte de la foto se muestra (posición y zoom) cuando dos lugares comparten imagen.

**Branding de un lugar:** en `data/branding.js`, agregar el id del lugar con su marca, color, imágenes (claves de `IMG` en `data/fotos.js`) y la lista de elementos. Aparecerá el botón "Ver branding" y la etiqueta "Brandeable".

**Textos del ciclo semanal:** en `data/ciclo.js`. Se puede usar `<b>…</b>` para negritas.

**Colores de cada mundo:** en `js/planta.js`, `const COL` (Pasado, Futuro, Presente). En la leyenda, `index.html` (`--c:#...`).

**Tipografía de títulos:** Integral CF (`assets/fuentes/IntegralCF-Regular.woff2`), declarada al inicio de `css/estilos.css`.

**Fondo o logo:** reemplazar `assets/fondo.webp` o `assets/logo.webp` por otro archivo con el mismo nombre.

## Verlo en tu computador

Por seguridad, los navegadores no cargan el modelo 3D si abres `index.html` con doble clic. Opciones:
- Visual Studio Code con la extensión **Live Server** → clic derecho en `index.html` → *Open with Live Server*.
- O en una terminal, dentro de la carpeta: `python3 -m http.server` y abrir `http://localhost:8000`.

## Publicar en GitHub Pages

Importante: en una cuenta gratuita, GitHub Pages solo funciona con repositorios **públicos**, y en ese caso cualquiera puede ver y descargar estos archivos editables (fotos y modelo incluidos).

**Opción recomendada (proyecto protegido):**
1. Guarda esta carpeta editable en un repositorio **privado** (o solo en tu computador).
2. Genera la versión con clave: `pip install cryptography` y luego
   `python3 herramientas/empaquetar.py --clave TU_CLAVE`
3. Sube solo `dist/index.html` (y `robots.txt`) al repositorio **público** que usas para GitHub Pages.

**Opción abierta (sin clave):** subir toda esta carpeta a un repositorio público y activar Pages en *Settings → Pages → Deploy from a branch → main → / (root)*.

Para subir la carpeta completa desde el navegador: pestaña **Code → Add file → Upload files** y arrastrar el contenido (no la carpeta contenedora), manteniendo las subcarpetas.

## Notas

- La librería 3D (three.js 0.160) y las tipografías se cargan desde internet; la página necesita conexión.
- El modelo 3D viene de `mo2027.obj` (SketchUp, versión de octubre), simplificado y con texturas reducidas para web. Si cambias el modelo, hay que volver a procesarlo; las formas de los lugares en la planta (`poly`/`circle` en `data/lugares.js`) están en metros sobre ese mismo modelo.
- La imagen `assets/planta.webp` es una vista superior del modelo; si el modelo cambia, también hay que regenerarla.
