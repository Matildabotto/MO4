#!/usr/bin/env python3
"""
Empaqueta el proyecto en UN solo archivo HTML (todo adentro: código, datos, fotos y modelo 3D).
Con --clave, además lo cifra (AES-256) y pide contraseña al abrirlo.

Uso (desde la carpeta del proyecto):
    python3 herramientas/empaquetar.py                      -> dist/index.html (sin clave)
    python3 herramientas/empaquetar.py --clave cookingmedia -> dist/index.html (con clave)

Para la versión con clave se necesita:  pip install cryptography
"""
import argparse, base64, gzip, json, os, re, sys

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MIME = {'.glb': 'application/octet-stream', '.dxf': 'application/dxf', '.pdf': 'application/pdf', '.woff2': 'font/woff2', '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml'}
RUTA = re.compile(r'(?:\.\./)?assets/[A-Za-z0-9_\-./]+\.(?:webp|png|jpe?g|svg|woff2|glb|dxf)')

def leer(p, modo='r'):
    with open(os.path.join(RAIZ, p), modo + ('' if modo == 'rb' else ''), **({} if modo == 'rb' else {'encoding': 'utf-8'})) as f:
        return f.read()

def data_uri(ruta):
    ruta = ruta.replace('../', '')
    ext = os.path.splitext(ruta)[1].lower()
    return f'data:{MIME[ext]};base64,' + base64.b64encode(leer(ruta, 'rb')).decode()

def incrustar_rutas(texto):
    return RUTA.sub(lambda m: data_uri(m.group(0)), texto)

def empaquetar():
    html = leer('index.html')
    # CSS en línea
    html = re.sub(r'<link rel="stylesheet" href="(css/[^"]+)">',
                  lambda m: '<style>\n' + incrustar_rutas(leer(m.group(1))) + '\n</style>', html)
    # JS clásico y módulos en línea
    html = re.sub(r'<script src="([^"]+)"></script>',
                  lambda m: '<script>\n' + incrustar_rutas(leer(m.group(1))) + '\n</script>', html)
    html = re.sub(r'<script type="module" src="([^"]+)"></script>',
                  lambda m: '<script type="module">\n' + incrustar_rutas(leer(m.group(1))) + '\n</script>', html)
    # imágenes del HTML
    html = incrustar_rutas(html)
    # modelo 3D dentro de window.__BIN__ (comprimido)
    binarios = {}
    for carpeta in ['modelo']:
        for nombre in sorted(os.listdir(os.path.join(RAIZ, carpeta))):
            if nombre.endswith('.glb'):
                ruta = f'{carpeta}/{nombre}'
                binarios[ruta] = base64.b64encode(gzip.compress(leer(ruta, 'rb'), 9)).decode()
    bloque = '<script>window.__BIN__ = ' + json.dumps(binarios) + ';</script>\n'
    html = html.replace('<!-- Datos editables -->', bloque + '<!-- Datos editables -->', 1)
    return html

def cifrar(html, clave):
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.primitives import hashes
    except ImportError:
        sys.exit('Falta la librería: ejecuta  pip install cryptography')
    datos = gzip.compress(html.encode('utf-8'), 9)
    sal, iv, it = os.urandom(16), os.urandom(12), 600000
    llave = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=sal, iterations=it).derive(clave.encode())
    cifrado = AESGCM(llave).encrypt(iv, datos, None)
    t = leer('herramientas/plantilla_clave.html')
    t = t.replace('__LOGO__', data_uri('assets/logo.webp')).replace('__FONDO__', data_uri('assets/fondo.webp'))
    t = t.replace('__COOKING__', data_uri('assets/cooking-media.webp'))
    t = t.replace('__PAYLOAD_META__', json.dumps({'salt': base64.b64encode(sal).decode(), 'iv': base64.b64encode(iv).decode(), 'iter': it}))
    return t.replace('__PAYLOAD__', base64.b64encode(cifrado).decode())

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Empaqueta Mundos Opuestos en un solo HTML.')
    ap.add_argument('--clave', help='contraseña para proteger la página (opcional)')
    ap.add_argument('--salida', default='dist/index.html')
    a = ap.parse_args()
    html = empaquetar()
    if a.clave: html = cifrar(html, a.clave)
    destino = os.path.join(RAIZ, a.salida); os.makedirs(os.path.dirname(destino), exist_ok=True)
    with open(destino, 'w', encoding='utf-8') as f: f.write(html)
    print(f'Listo: {a.salida}  ({len(html)/1e6:.1f} MB){"  · con clave" if a.clave else ""}')
